package javaapplication1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.*;

public class JavaApplication1 {

    public static Statement st;
    public static Connection con;

    public static void main(String[] args) {

        // Path to the 'Documents' directory
        String path = System.getProperty("user.home") + "/Documents";

        //String path = "C:/Users/dz laptops/Documents";
        // Create a File object for the directory
        File dir = new File(path);

        // Create a File object for the 'BddInfos.txt' file
        File file = new File(dir, "BddInfos.txt");

        try {
            // Check if the file exists
            if (file.exists()) {

                //sql connection
                con = null;

                String IP = "";
                String User = "";
                String mdp = "";
                String Port = "";
                String BDD = "";

                try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                    IP = br.readLine();
                    User = br.readLine();
                    mdp = br.readLine();
                    Port = br.readLine();
                    BDD = br.readLine();
                } catch (IOException e) {
                    System.err.format("IOException: %s%n", e);
                }

                try {
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    con = (Connection) DriverManager.getConnection("jdbc:mysql://" + IP + ":" + Port + "/" + BDD + "", "" + User + "", "" + mdp + "");
                    if (con != null) {
                        System.out.print("Connected");
                        f1 f = new f1();
                        f.setVisible(true);
                        st = con.createStatement();
                    }
                } catch (Exception e) {
                    System.out.print("Not Connected : " + e);
                    // Open the BddConnection interface
                    BddConnection frameConnection = new BddConnection();
                    frameConnection.setVisible(true);
                }
            } else {
                throw new Exception("File not found");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());

            // Open the BddConnection interface
            BddConnection frameConnection = new BddConnection();
            frameConnection.setVisible(true);
        }

    }
}


//con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/pfe_schema", "pfe", "pfe2023");
