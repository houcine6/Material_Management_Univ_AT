package javaapplication1;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import static javaapplication1.JavaApplication1.con;
import static javaapplication1.JavaApplication1.st;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.swing.border.AbstractBorder;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;

public class f1 extends javax.swing.JFrame {

    public f1() {

        initComponents();
        Setframeicon();
        this.setBackground(new Color(0.0f, 0.0f, 0.0f, 0.0f));

    }

    private void Setframeicon() {
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/images/app logo.png")));
    }

    /*private void Setframeicon() {
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/images/app logo.png")));
    }*/
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new RoundedPanel(50, 50, Color.WHITE);
        jLabel9 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jTextField1 = new RoundedJTextField(50);
        jPasswordField1 = new RoundedJPasswordField(50);
        ImageIcon btnIcone = new ImageIcon(getClass().getResource("/images/téléchargement.png"));
        jButton1 = new RoundButton(230,230,btnIcone);
        ImageIcon icon = new ImageIcon(getClass().getResource("/images/faded blue.jpg"));
        jLabel1 = new RoundedLabel("",icon,JLabel.CENTER, 50, 50);
        jPanel1 = new javax.swing.JPanel();
        jButton41 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setMinimumSize(new java.awt.Dimension(1047, 601));
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setMaximumSize(new java.awt.Dimension(1047, 601));
        jPanel2.setMinimumSize(new java.awt.Dimension(1047, 601));
        jPanel2.setPreferredSize(new java.awt.Dimension(1047, 601));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Roboto Condensed", 0, 16)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(102, 102, 102));
        jLabel9.setText("Developed By @Chander Marwa et @Benbouha Djihene"); // NOI18N
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 560, 410, 30));

        jLabel2.setFont(new java.awt.Font("Roboto Condensed", 0, 16)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText(".Université de Ain Témouchent © 2023. Tous droits réservés."); // NOI18N
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 530, 470, 30));

        jLabel8.setFont(new java.awt.Font("Roboto Condensed", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("<html>Introducing EQUILOG, the ultimate solution for material management at our university.\n                This Java-based app, created with NetBeans Designer and utilizing a MySQL database with 16 tables, \n                offers streamlined management functionalities for 7 different user types. From administration to staff, \n                EQUILOG offers specific features to simplify their daily tasks. Additionally, \n                EQUILOG features a messaging system to enhance collaboration and communication between users. \n                With its ability to operate on multiple PCs simultaneously through a network and server, \n                EQUILOG provides a seamless and efficient management experience. \n                Don't miss out on the opportunity to revolutionize your university's material management - try EQUILOG today!</html>"); // NOI18N
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 130, 460, 320));

        jLabel3.setFont(new java.awt.Font("Roboto Condensed", 1, 40)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("EQUILOG");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 40, 210, 120));

        jLabel4.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(102, 102, 102));
        jLabel4.setText("Password :");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 340, 140, 30));

        jLabel5.setFont(new java.awt.Font("Dialog", 1, 48)); // NOI18N
        jLabel5.setText("LOGIN");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 70, 160, 50));

        jLabel6.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(102, 102, 102));
        jLabel6.setText("E-mail:");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 190, 80, 30));

        jTextField1.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jTextField1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 204), 1, true));
        jTextField1.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jTextField1.setMaximumSize(new java.awt.Dimension(102, 32));
        jTextField1.setMinimumSize(new java.awt.Dimension(102, 32));
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        jPanel2.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 230, 320, 50));

        jPasswordField1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 204), 1, true));
        jPasswordField1.setMaximumSize(new java.awt.Dimension(2, 26));
        jPasswordField1.setMinimumSize(new java.awt.Dimension(2, 26));
        jPasswordField1.setPreferredSize(new java.awt.Dimension(2, 26));
        jPasswordField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordField1ActionPerformed(evt);
            }
        });
        jPanel2.add(jPasswordField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 380, 320, 50));

        jButton1.setBackground(new java.awt.Color(173, 186, 230));
        jButton1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Log in");
        jButton1.setAlignmentY(0.0F);
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jButton1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jButton1KeyPressed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 470, 140, 50));

        jLabel1.setOpaque(true);
        jLabel1.setBorder(new RoundedBorder(jPanel2.getBackground(), 50, 00));
        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/faded blue.jpg"))); // NOI18N
        jLabel1.setAlignmentY(0.0F);
        jLabel1.setOpaque(true);
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 590, 600));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setOpaque(false);
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton41.setBackground(new java.awt.Color(255, 255, 255));
        jButton41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Exit.png"))); // NOI18N
        jButton41.setBorder(null);
        jButton41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton41ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton41, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 10, -1, -1));

        jPanel2.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 0, 460, 600));

        jLabel7.setFont(new java.awt.Font("Roboto Condensed", 1, 40)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("EQUILOG");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 40, 210, 120));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 600));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public static String USER;
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        String email = jTextField1.getText();
        char[] passwordChars = jPasswordField1.getPassword();
        String password = new String(passwordChars);

        String monProfilSql = "SELECT * FROM pfe_schema.mon_profil WHERE email = ? AND mdp = ?";

        String profilViseRecteurSql = "SELECT * FROM pfe_schema.profil_viserecteur WHERE email = ? AND mdp = ?";

        String profilSGSql = "SELECT * FROM pfe_schema.profil_sg WHERE email = ? AND mdp = ?";

        String profilDoyenSql = "SELECT email,mdp,faculte FROM pfe_schema.profil_doyen WHERE email = ? AND mdp = ?;";
        try {

            PreparedStatement monProfilStatement = con.prepareStatement(monProfilSql);
            monProfilStatement.setString(1, email);
            monProfilStatement.setString(2, password);
            ResultSet monProfilResult = monProfilStatement.executeQuery();

            boolean isValidLogin = false;
            if (monProfilResult.next()) {
                // Valid login for mon_profil table
                UT1 ut1 = new UT1();
                ut1.setVisible(true);
                this.setVisible(false);
                // Valid login for mon_profil table
                isValidLogin = true;
            }
            if (isValidLogin) {
                // email and password are correct
                jTextField1.setBackground(Color.white);
                jPasswordField1.setBackground(Color.white);
            } else {
                // email or password is incorrect
                if (!email.equals("")) {
                    jTextField1.setBackground(Color.red);
                }
                if (passwordChars.length > 0) {
                    jPasswordField1.setBackground(Color.red);
                }
            }

            PreparedStatement profilViseRecteurStatement = con.prepareStatement(profilViseRecteurSql);
            profilViseRecteurStatement.setString(1, email);
            profilViseRecteurStatement.setString(2, password);
            ResultSet profilViseRecteurResult = profilViseRecteurStatement.executeQuery();
            if (profilViseRecteurResult.next()) {
                // Valid login for mon_profil table
                ViseRecteur ut2 = new ViseRecteur();
                ut2.setVisible(true);
                this.setVisible(false);
                // Valid login for mon_profil table
                isValidLogin = true;
            }
            if (isValidLogin) {
                // email and password are correct
                jTextField1.setBackground(Color.white);
                jPasswordField1.setBackground(Color.white);
            } else {
                // email or password is incorrect
                if (!email.equals("")) {
                    jTextField1.setBackground(Color.red);
                }
                if (passwordChars.length > 0) {
                    jPasswordField1.setBackground(Color.red);
                }
            }

            PreparedStatement profilSGStatement = con.prepareStatement(profilSGSql);
            profilSGStatement.setString(1, email);
            profilSGStatement.setString(2, password);
            ResultSet profilSGResult = profilSGStatement.executeQuery();
            if (profilSGResult.next()) {
                // Valid login for mon_profil table
                SG sg = new SG();
                sg.setVisible(true);
                this.setVisible(false);
                // Valid login for mon_profil table
                isValidLogin = true;
            }
            if (isValidLogin) {
                // email and password are correct
                jTextField1.setBackground(Color.white);
                jPasswordField1.setBackground(Color.white);
            } else {
                // email or password is incorrect
                if (!email.equals("")) {
                    jTextField1.setBackground(Color.red);
                }
                if (passwordChars.length > 0) {
                    jPasswordField1.setBackground(Color.red);
                }
            }

            PreparedStatement profilDoyenStatement = con.prepareStatement(profilDoyenSql);
            profilDoyenStatement.setString(1, email);
            profilDoyenStatement.setString(2, password);
            ResultSet profilDoyenResult = profilDoyenStatement.executeQuery();
            if (profilDoyenResult.next()) {
                // Valid login for mon_profil table
                USER = profilDoyenResult.getString("faculte");

                Doyen ut3 = new Doyen();
                ut3.setVisible(true);
                this.setVisible(false);
                // Valid login for mon_profil table
                isValidLogin = true;
            }
            if (isValidLogin) {
                // email and password are correct
                jTextField1.setBackground(Color.white);
                jPasswordField1.setBackground(Color.white);
            } else {
                // email or password is incorrect
                if (!email.equals("")) {
                    jTextField1.setBackground(Color.red);
                }
                if (passwordChars.length > 0) {
                    jPasswordField1.setBackground(Color.red);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(f1.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jButton1KeyPressed

    }//GEN-LAST:event_jButton1KeyPressed

    private void jPasswordField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordField1ActionPerformed
        jButton1.doClick();
    }//GEN-LAST:event_jPasswordField1ActionPerformed

    private void jButton41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton41ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jButton41ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        jButton1.doClick();
    }//GEN-LAST:event_jTextField1ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(f1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(f1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(f1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(f1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new f1().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton41;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables

    private class RoundedPanel extends JPanel {

        private int arcWidth;
        private int arcHeight;
        private Color borderColor;

        public RoundedPanel(int arcWidth, int arcHeight, Color borderColor) {
            this.arcWidth = arcWidth;
            this.arcHeight = arcHeight;
            this.borderColor = borderColor;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), arcWidth, arcHeight);
            g2.setColor(borderColor);
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arcWidth, arcHeight);
            g2.dispose();
        }
    }

    public class RoundedBorder extends AbstractBorder {

        private Color color;
        private int arcWidth;
        private int arcHeight;

        public RoundedBorder(Color color, int arcWidth, int arcHeight) {
            this.color = color;
            this.arcWidth = arcWidth;
            this.arcHeight = arcHeight;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // Create a rounded rectangle with the same shape as the panel
            RoundRectangle2D.Float roundRect = new RoundRectangle2D.Float(x, y, width - 1, height - 1, arcWidth, arcHeight);

            // Draw the border
            g2d.setColor(color);
            g2d.draw(roundRect);

            g2d.dispose();
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(arcHeight, arcWidth, arcHeight, arcWidth);
        }

        @Override
        public Insets getBorderInsets(Component c, Insets insets) {
            insets.left = arcWidth;
            insets.top = arcHeight;
            insets.right = arcWidth;
            insets.bottom = arcHeight;
            return insets;
        }
    }

    public class RoundedLabel extends JLabel {

        private int arcWidth;
        private int arcHeight;

        public RoundedLabel() {
            super();
            setOpaque(true);
            arcWidth = 20;
            arcHeight = 20;
        }

        public RoundedLabel(String text) {
            super(text);
            setOpaque(true);
            arcWidth = 20;
            arcHeight = 20;
        }

        public RoundedLabel(ImageIcon icon) {
            super(icon);
            setOpaque(true);
            arcWidth = 20;
            arcHeight = 20;
        }

        public RoundedLabel(String text, ImageIcon icon, int horizontalAlignment) {
            super(text, icon, horizontalAlignment);
            setOpaque(true);
            arcWidth = 20;
            arcHeight = 20;
        }

        public RoundedLabel(int arcWidth, int arcHeight) {
            super();
            setOpaque(true);
            this.arcWidth = arcWidth;
            this.arcHeight = arcHeight;
        }

        public RoundedLabel(String text, int arcWidth, int arcHeight) {
            super(text);
            setOpaque(true);
            this.arcWidth = arcWidth;
            this.arcHeight = arcHeight;
        }

        public RoundedLabel(ImageIcon icon, int arcWidth, int arcHeight) {
            super(icon);
            setOpaque(true);
            this.arcWidth = arcWidth;
            this.arcHeight = arcHeight;
        }

        public RoundedLabel(String text, ImageIcon icon, int horizontalAlignment, int arcWidth, int arcHeight) {
            super(text, icon, horizontalAlignment);
            setOpaque(true);
            this.arcWidth = arcWidth;
            this.arcHeight = arcHeight;
        }

        public int getArcWidth() {
            return arcWidth;
        }

        public void setArcWidth(int arcWidth) {
            this.arcWidth = arcWidth;
            repaint();
        }

        public int getArcHeight() {
            return arcHeight;
        }

        public void setArcHeight(int arcHeight) {
            this.arcHeight = arcHeight;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            RoundRectangle2D.Float roundRect = new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), arcWidth, arcHeight);
            g2.clip(roundRect);
            super.paintComponent(g);
        }

        @Override
        protected void paintBorder(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(Color.white);
            RoundRectangle2D.Float roundRect = new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, arcWidth, arcHeight);
            g2.draw(roundRect);
        }
    }

    public class RoundButton extends JButton {

        private int cornerRadius;
        private Icon icon;

        public RoundButton(int width, int height, Icon icon) {
            this.cornerRadius = 50; // you can adjust this value as needed
            this.icon = null;
            setOpaque(false);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setVerticalTextPosition(JButton.CENTER); // Set the vertical position of the text
            setHorizontalTextPosition(JButton.CENTER);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            paintButton(g);
            paintIcon(g);
            paintText(g);
        }

        private void paintText(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getForeground());
            g2.setFont(getFont());
            g2.drawString(getText(), getWidth() / 2 - g2.getFontMetrics().stringWidth(getText()) / 2, getHeight() / 2 + g2.getFontMetrics().getHeight() / 3); // Draw the text centered on the button
            g2.dispose();
        }

        private void paintButton(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int width = getWidth();
            int height = getHeight();
            RoundRectangle2D shape = new RoundRectangle2D.Float(0, 0, width, height, cornerRadius, cornerRadius);
            g2.clip(shape);
            g2.setColor(getBackground());
            g2.fillRect(0, 0, width, height);
            g2.setColor(getForeground());
            g2.draw(shape);
            g2.dispose();
        }

        private void paintIcon(Graphics g) {
            if (icon != null) {
                Graphics2D g2 = (Graphics2D) g.create();
                //g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int width = getWidth();
                int height = getHeight();
                //int iconSize = Math.min(width, height) - 2 * cornerRadius;
                int iconX = (width - 140);
                int iconY = (height - 50);
                RoundRectangle2D iconShape = new RoundRectangle2D.Float(iconX, iconY, width, height, cornerRadius, cornerRadius);
                g2.setClip(iconShape);
                icon.paintIcon(this, g2, iconX, iconY);
                g2.dispose();
            }
        }

        /*private void paintIcon(Graphics g) {
            if (icon != null) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int width = getWidth();
                int height = getHeight();
                RoundRectangle2D shape = new RoundRectangle2D.Float(0, 0, width, height, cornerRadius, cornerRadius);
                RoundRectangle2D iconShape = new RoundRectangle2D.Float((float) shape.getX() + cornerRadius, (float) shape.getY() + cornerRadius,
                        (float) shape.getWidth() - 2 * cornerRadius, (float) shape.getHeight() - 2 * cornerRadius,
                        cornerRadius, cornerRadius);
                g2.setClip(iconShape);
                icon.paintIcon(this, g2, (int) iconShape.getX(), (int) iconShape.getY());
                g2.dispose();
            }
        }*/
        @Override
        public Dimension getPreferredSize() {
            return new Dimension(2 * cornerRadius, 2 * cornerRadius);
        }
    }

    public class RoundedJTextField extends JTextField {

        private Shape shape;

        public RoundedJTextField(int size) {
            super(size);
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            g.setColor(getBackground());
            g.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 40, 40);
            super.paintComponent(g);
        }

        @Override
        protected void paintBorder(Graphics g) {
            g.setColor(new Color(204, 204, 204));
            g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 40, 40);
        }

        @Override
        public boolean contains(int x, int y) {
            if (shape == null || !shape.getBounds().equals(getBounds())) {
                shape = new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 40, 40);
            }
            return shape.contains(x, y);
        }
    }

    public class RoundedJPasswordField extends JPasswordField {

        private Shape shape;

        public RoundedJPasswordField(int size) {
            super(size);
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            g.setColor(getBackground());
            g.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 40, 40);
            super.paintComponent(g);
        }

        @Override
        protected void paintBorder(Graphics g) {
            g.setColor(new Color(204, 204, 204));
            g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 40, 40);
        }

        @Override
        public boolean contains(int x, int y) {
            if (shape == null || !shape.getBounds().equals(getBounds())) {
                shape = new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 40, 40);
            }
            return shape.contains(x, y);
        }
    }
}
