package javaapplication1;

import java.sql.ResultSet;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.Toolkit;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javaapplication1.JavaApplication1.con;
import static javaapplication1.JavaApplication1.st;
import javax.imageio.ImageIO;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JWindow;
import javax.swing.Timer;
import javax.swing.border.AbstractBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ViseRecteur extends javax.swing.JFrame {

    public ViseRecteur() {
        initComponents();
        Setframeicon();
        this.setBackground(new Color(0.0f, 0.0f, 0.0f, 0.0f));
        loadFirstScreen();

        // Get today's date
        Date today = new Date();

        // Set the date format of jDateChooser1
        jDateChooser1.setDateFormatString("yyyy MMM d");

        // Set the date in jDateChooser1
        jDateChooser1.setDate(today);
        try {
            loadDB(1);
            loadDB(40);
            loadMessagerie();
        } catch (Exception e) {
            System.out.print("exp :" + e);
        }
    }

    private void Setframeicon() {
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/images/app logo.png")));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jFrame1 = new javax.swing.JFrame();
        jLayeredPane2 = new RoundedLayeredPanel(50, 50, Color.WHITE);
        jPanel13 = new javax.swing.JPanel();
        jScrollPane12 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        jButton42 = new javax.swing.JButton();
        jPanel14 = new javax.swing.JPanel();
        jScrollPane11 = new javax.swing.JScrollPane();
        jTextArea1 = new RoundedJTextArea(5, 20);
        jLabel23 = new javax.swing.JLabel();
        jButton40 = new RoundedButton(23, 23);
        jButton41 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenuItem6 = new javax.swing.JMenuItem();
        jMenuItem7 = new javax.swing.JMenuItem();
        jMenuItem8 = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        jMenuItem3 = new javax.swing.JMenuItem();
        jFrame2 = new javax.swing.JFrame();
        jPanel16 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jTextField2 = new RoundedJTextField(10);
        jTextField3 = new RoundedJTextField(10);
        jTextField1 = new RoundedJTextField(10);
        jComboBox3 = new javax.swing.JComboBox<>();
        jLabel16 = new javax.swing.JLabel();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jTextField5 = new RoundedJTextField(10);
        jTextField6 = new RoundedJTextField(10);
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jLabel37 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jButton45 = new RoundedButton(23, 23);
        jButton14 = new RoundedButton(23, 23);
        jButton13 = new RoundedButton(23, 23);
        jLabel18 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        jFrame3 = new javax.swing.JFrame();
        jPanel17 = new javax.swing.JPanel();
        jLabel72 = new javax.swing.JLabel();
        jTextField18 = new RoundedJTextField(10);
        jTextField19 = new RoundedJTextField(10);
        jTextField20 = new RoundedJTextField(10);
        jComboBox11 = new javax.swing.JComboBox<>();
        jLabel73 = new javax.swing.JLabel();
        jDateChooser2 = new com.toedter.calendar.JDateChooser();
        jTextField21 = new RoundedJTextField(10);
        jRadioButton3 = new javax.swing.JRadioButton();
        jRadioButton4 = new javax.swing.JRadioButton();
        jLabel74 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jButton47 = new RoundedButton(23, 23);
        jButton48 = new RoundedButton(23, 23);
        jButton49 = new RoundedButton(23, 23);
        jLabel77 = new javax.swing.JLabel();
        jLabel78 = new javax.swing.JLabel();
        jLabel79 = new javax.swing.JLabel();
        jLabel80 = new javax.swing.JLabel();
        jTextField23 = new RoundedJTextField(10);
        jTextField22 = new RoundedJTextField(10);
        jLabel81 = new javax.swing.JLabel();
        Color transparentWhitegeneral = new Color(255, 255, 255, 0);
        jPanel12 = new RoundedPanel(50, 50, transparentWhitegeneral);
        jLayeredPane1 = new javax.swing.JLayeredPane();
        Color transparentWhiteP = new Color(255, 255, 255, 0);
        jPanel3 = new RoundedPanel(50, 50,transparentWhiteP );
        jButton21 = new RoundedButton(23, 23);
        Color transparentWhitep2 = new Color(255, 255, 255, 0);
        jPanel25 = new RoundedPanel(50, 50,transparentWhitep2 );
        jLabel47 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        jTable9 = new javax.swing.JTable();
        jButton34 = new javax.swing.JButton();
        jLabel44 = new javax.swing.JLabel();
        jTextField14 = new RoundedJTextField(10);
        jLabel45 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel2 = new RoundedLabel("",null,JLabel.CENTER, 50, 50);
        jButton32 = new javax.swing.JButton();
        jPasswordField1 = new RoundedJPasswordField(50);
        Color transparentWhitest = new Color(255, 255, 255, 0);
        jPanel9 = new RoundedPanel(50, 50, transparentWhitest);
        jButton5 = new RoundedButton(23, 23);
        jLabel8 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jButton38 = new RoundedButton(23, 23);
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        Color transparentWhitest2 = new Color(255, 255, 255, 0);
        jPanel19 = new RoundedPanel(50, 50, transparentWhitest2);
        jComboBox5 = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jTextField7 = new RoundedJTextField(10);
        jLabel15 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jButton12 = new RoundedButton(23, 23);
        jButton51 = new RoundedButton(23, 23);
        jPanel4 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel89 = new javax.swing.JLabel();
        ImageIcon iconA = new ImageIcon(getClass().getResource("/images/accueil.jpeg"));
        jLabel3 = new RoundedLabel("",iconA,JLabel.CENTER, 50, 50);
        Color transparent44 = new Color(255, 255, 255, 0);
        jPanel15 = new RoundedPanel(50, 50, transparent44);
        jScrollPane13 = new javax.swing.JScrollPane();
        jTable11 = new javax.swing.JTable();
        Color t44 = new Color(255, 255, 255, 0);
        jPanel27 = new RoundedPanel(50, 50, t44);
        jLabel68 = new javax.swing.JLabel();
        jComboBox10 = new javax.swing.JComboBox<>();
        jButton43 = new javax.swing.JButton();
        jTextField17 = new RoundedJTextField(10);
        jLabel58 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jButton44 = new RoundedButton(23, 23);
        jLabel69 = new javax.swing.JLabel();
        Color transparent1 = new Color(255, 255, 255, 0);
        jPanel11 = new RoundedPanel(50, 50, transparent1);
        Color t1 = new Color(255, 255, 255, 0);
        jPanel26 = new RoundedPanel(50, 50, t1);
        jLabel65 = new javax.swing.JLabel();
        jComboBox9 = new javax.swing.JComboBox<>();
        jButton35 = new javax.swing.JButton();
        jTextField13 = new RoundedJTextField(10);
        jLabel82 = new javax.swing.JLabel();
        jScrollPane10 = new javax.swing.JScrollPane();
        jTable10 = new javax.swing.JTable();
        jLabel38 = new javax.swing.JLabel();
        jButton36 = new RoundedButton(23, 23);
        jLabel66 = new javax.swing.JLabel();
        Color transparent4 = new Color(255, 255, 255, 0);
        jPanel6 = new RoundedPanel(50, 50, transparent4);
        Color t80 = new Color(255, 255, 255, 0);
        jPanel21 = new RoundedPanel(50, 50, t80);
        jLabel62 = new javax.swing.JLabel();
        jComboBox6 = new javax.swing.JComboBox<>();
        jButton22 = new javax.swing.JButton();
        jTextField9 = new RoundedJTextField(10);
        jLabel35 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        jButton23 = new RoundedButton(23, 23);
        jLabel28 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        Color transparent3 = new Color(255, 255, 255, 0);
        jPanel7 = new RoundedPanel(50, 50, transparent3);
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable5 = new javax.swing.JTable();
        Color t3 = new Color(255, 255, 255, 0);
        jPanel22 = new RoundedPanel(50, 50, t3);
        jLabel59 = new javax.swing.JLabel();
        jComboBox7 = new javax.swing.JComboBox<>();
        jButton24 = new javax.swing.JButton();
        jTextField10 = new RoundedJTextField(10);
        jLabel43 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jButton25 = new RoundedButton(23, 23);
        jLabel60 = new javax.swing.JLabel();
        Color transparentWhitedep = new Color(255, 255, 255, 0);
        jPanel10 = new RoundedPanel(50, 50, transparentWhitedep);
        Color transparentWhitedep2 = new Color(255, 255, 255, 0);
        jPanel24 = new RoundedPanel(50, 50, transparentWhitedep2);
        jLabel56 = new javax.swing.JLabel();
        jButton28 = new javax.swing.JButton();
        jTextField12 = new RoundedJTextField(10);
        jLabel57 = new javax.swing.JLabel();
        jPanel23 = new RoundedPanel(50, 50, Color.BLACK);
        jScrollPane14 = new javax.swing.JScrollPane();
        jTable8 = new javax.swing.JTable();
        jLabel41 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jButton52 = new RoundedButton(23, 23);
        jButton53 = new RoundedButton(23, 23);
        jButton54 = new RoundedButton(23, 23);
        jTextField4 = new RoundedJTextField(10);
        jLabel46 = new javax.swing.JLabel();
        jLabel83 = new javax.swing.JLabel();
        Color transparentWhitem = new Color(255, 255, 255, 0);
        jPanel8 = new RoundedPanel(50, 50, transparentWhitem);
        Color t880m = new Color(255, 255, 255, 0);
        jPanel29 = new RoundedPanel(50, 50, t880m);
        jLabel84 = new javax.swing.JLabel();
        jComboBox8 = new javax.swing.JComboBox<>();
        jButton29 = new javax.swing.JButton();
        jTextField11 = new RoundedJTextField(10);
        jLabel40 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable6 = new javax.swing.JTable();
        jLabel24 = new javax.swing.JLabel();
        jScrollPane15 = new javax.swing.JScrollPane();
        jTable13 = new javax.swing.JTable();
        jLabel14 = new javax.swing.JLabel();
        jPanel30 = new RoundedPanel(50, 50, Color.BLACK);
        jButton31 = new RoundedButton(23, 23);
        jLabel30 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jTextField15 = new RoundedJTextField(10);
        jTextField16 = new RoundedJTextField(10);
        Color transparentWhite = new Color(255, 255, 255, 0);
        jPanel5 = new RoundedPanel(50, 50, transparentWhite);
        jLabel5 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTable7 = new javax.swing.JTable();
        Color t880 = new Color(255, 255, 255, 0);
        jPanel20 = new RoundedPanel(50, 50, t880);
        jLabel63 = new javax.swing.JLabel();
        jButton15 = new RoundedButton(23, 23);
        jComboBox4 = new javax.swing.JComboBox<>();
        jButton18 = new javax.swing.JButton();
        jTextField8 = new RoundedJTextField(10);
        jLabel39 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel22 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jButton20 = new RoundedButton(23, 23);
        jLabel6 = new javax.swing.JLabel();
        jPanel28 = new RoundedPanel(50, 50, Color.BLACK);
        jButton19 = new RoundedButton(23, 23);
        jComboBox2 = new javax.swing.JComboBox<>();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel29 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButton50 = new RoundedButton(23, 23);
        Color transparentWhitep = new Color(255, 255, 255, 0);
        jPanel2 = new RoundedPanel(50, 50, transparentWhitep);
        jLabel67 = new javax.swing.JLabel();
        jButton39 = new RoundedButton(30, 30);
        jLabel7 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        jButton33 = new RoundedButton(30, 30);
        jButton16 = new RoundedButton(30, 30);
        jButton10 = new RoundedButton(30, 30);
        jButton6 = new RoundedButton(30, 30);
        jButton7 = new RoundedButton(30, 30);
        jButton9 = new RoundedButton(30, 30);
        jButton11 = new RoundedButton(30, 30);
        jButton17 = new RoundedButton(30, 30);
        jLabel10 = new javax.swing.JLabel();
        jButton26 = new RoundedButton(30, 30);
        jLabel52 = new javax.swing.JLabel();
        ImageIcon icon = new ImageIcon(getClass().getResource("/images/faded blue.jpg"));
        jLabel1 = new RoundedLabel("",icon,JLabel.CENTER, 50, 50);
        jPanel1 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton37 = new javax.swing.JButton();
        jLabel25 = new javax.swing.JLabel();

        jFrame1.setMinimumSize(new java.awt.Dimension(585, 423));
        jFrame1.setResizable(false);

        jLayeredPane2.setOpaque(false);
        jLayeredPane2.setBackground(new java.awt.Color(0, 0, 0));
        jLayeredPane2.setMinimumSize(null);
        jLayeredPane2.setLayout(new java.awt.CardLayout());

        jPanel13.setBackground(new java.awt.Color(255, 255, 255));
        jPanel13.setName(""); // NOI18N

        jList1.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane12.setViewportView(jList1);

        jButton42.setBackground(new java.awt.Color(255, 255, 255));
        jButton42.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/clear.png"))); // NOI18N
        jButton42.setText("Clear");
        jButton42.setBorder(null);
        jButton42.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton42.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton42ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 453, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton42))
                .addContainerGap(69, Short.MAX_VALUE))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton42)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane12, javax.swing.GroupLayout.DEFAULT_SIZE, 323, Short.MAX_VALUE)
                .addContainerGap())
        );

        jLayeredPane2.add(jPanel13, "card3");

        jPanel14.setBackground(new java.awt.Color(255, 255, 255));

        jScrollPane11.setBorder(null);
        jScrollPane11.setOpaque(false);

        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Courier New", 0, 12)); // NOI18N
        jTextArea1.setRows(5);
        jTextArea1.setText("\n");
        jTextArea1.setOpaque(false);
        jScrollPane11.setViewportView(jTextArea1);

        jLabel23.setText("Message:");

        jButton40.setBackground(new java.awt.Color(204, 204, 204));
        jButton40.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/send msg.png"))); // NOI18N
        jButton40.setText("Send");
        jButton40.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton40.setOpaque(false);
        jButton40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton40ActionPerformed(evt);
            }
        });

        jButton41.setBackground(new java.awt.Color(255, 255, 255));
        jButton41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/back.png"))); // NOI18N
        jButton41.setBorder(null);
        jButton41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton41ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGap(81, 81, 81)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton40, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel23))
                .addContainerGap(91, Short.MAX_VALUE))
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addComponent(jButton41)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                .addComponent(jButton41, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 77, Short.MAX_VALUE)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton40)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addComponent(jLabel23)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(121, 121, 121))
        );

        jLayeredPane2.add(jPanel14, "card2");

        jMenuBar1.setBackground(new java.awt.Color(204, 204, 204));

        jMenu1.setBackground(new java.awt.Color(255, 255, 255));
        jMenu1.setText("Message");

        jMenuItem2.setText("Recteur");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenu2.setText("Doyen");

        jMenuItem4.setText("ST");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem4);

        jMenuItem5.setText("DROIT");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem5);

        jMenuItem6.setText("SEGSH");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem6);

        jMenuItem7.setText("LLSH");
        jMenuItem7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem7ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem7);

        jMenu1.add(jMenu2);

        jMenuItem8.setText("SG");
        jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem8ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem8);
        jMenu1.add(jSeparator1);

        jMenuItem3.setText("Exit");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuBar1.add(jMenu1);

        jFrame1.setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout jFrame1Layout = new javax.swing.GroupLayout(jFrame1.getContentPane());
        jFrame1.getContentPane().setLayout(jFrame1Layout);
        jFrame1Layout.setHorizontalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLayeredPane2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jFrame1Layout.setVerticalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLayeredPane2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jFrame2.setMinimumSize(new java.awt.Dimension(790, 520));
        jFrame2.setResizable(false);

        jPanel16.setBackground(new java.awt.Color(255, 255, 255));
        jPanel16.setMaximumSize(new java.awt.Dimension(790, 520));
        jPanel16.setMinimumSize(new java.awt.Dimension(790, 520));
        jPanel16.setPreferredSize(new java.awt.Dimension(790, 520));
        jPanel16.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel21.setText("Consommable:");
        jPanel16.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 290, -1, -1));
        jPanel16.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 220, 197, 32));
        jPanel16.add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 310, 197, 33));
        jPanel16.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, 197, 33));

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Neuf", "Bon", "Moyen", "Mauvais" }));
        jPanel16.add(jComboBox3, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 120, 200, 30));

        jLabel16.setFont(new java.awt.Font("Roboto Condensed", 0, 48)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Nouveau Matériel:");
        jPanel16.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 360, 50));

        jDateChooser1.setBackground(new java.awt.Color(255, 255, 255));
        jDateChooser1.setDateFormatString("yyyy MMM d");
        jPanel16.add(jDateChooser1, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 220, 197, 33));
        jPanel16.add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 350, 197, 33));
        jPanel16.add(jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 220, 197, 33));

        jRadioButton1.setText("Oui");
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });
        jPanel16.add(jRadioButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 310, -1, -1));

        jRadioButton2.setText("Non");
        jRadioButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton2ActionPerformed(evt);
            }
        });
        jPanel16.add(jRadioButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 310, -1, -1));

        jLabel37.setText("Fournisseur:");
        jPanel16.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 200, -1, -1));

        jLabel20.setText("Date:");
        jPanel16.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 200, -1, -1));

        jLabel19.setText("Etats:");
        jPanel16.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 100, -1, -1));

        jButton45.setBackground(new java.awt.Color(255, 255, 255));
        jButton45.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/backspace.png"))); // NOI18N
        jButton45.setText(" Effacer Tout ");
        jButton45.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        jButton45.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton45ActionPerformed(evt);
            }
        });
        jPanel16.add(jButton45, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 420, -1, -1));

        jButton14.setBackground(new java.awt.Color(255, 255, 255));
        jButton14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cancel.png"))); // NOI18N
        jButton14.setText(" Annuler ");
        jButton14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });
        jPanel16.add(jButton14, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 420, -1, -1));

        jButton13.setBackground(new java.awt.Color(255, 255, 255));
        jButton13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/save-icon_45x45.png"))); // NOI18N
        jButton13.setText(" Save ");
        jButton13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });
        jPanel16.add(jButton13, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 420, -1, -1));

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/faded blue header.jpg"))); // NOI18N
        jPanel16.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 790, 70));

        jLabel17.setText("N° inventaire:");
        jPanel16.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, -1, -1));

        jLabel70.setText("Caractéristiques:");
        jPanel16.add(jLabel70, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 290, -1, -1));

        jLabel71.setText("Nom Matériel:");
        jPanel16.add(jLabel71, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, -1, -1));

        javax.swing.GroupLayout jFrame2Layout = new javax.swing.GroupLayout(jFrame2.getContentPane());
        jFrame2.getContentPane().setLayout(jFrame2Layout);
        jFrame2Layout.setHorizontalGroup(
            jFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jFrame2Layout.setVerticalGroup(
            jFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        jFrame3.setMinimumSize(new java.awt.Dimension(790, 520));
        jFrame3.setResizable(false);

        jPanel17.setBackground(new java.awt.Color(255, 255, 255));
        jPanel17.setMaximumSize(new java.awt.Dimension(790, 520));
        jPanel17.setMinimumSize(new java.awt.Dimension(790, 520));
        jPanel17.setPreferredSize(new java.awt.Dimension(790, 520));
        jPanel17.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel72.setText("Consommable:");
        jPanel17.add(jLabel72, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 290, -1, -1));
        jPanel17.add(jTextField18, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 220, 197, 32));
        jPanel17.add(jTextField19, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 310, 197, 33));
        jPanel17.add(jTextField20, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, 197, 33));

        jComboBox11.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Neuf", "Bon", "Moyen", "Mauvais" }));
        jPanel17.add(jComboBox11, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 130, 200, 30));

        jLabel73.setFont(new java.awt.Font("Roboto Condensed", 0, 48)); // NOI18N
        jLabel73.setForeground(new java.awt.Color(255, 255, 255));
        jLabel73.setText("Modifier Matériel:");
        jPanel17.add(jLabel73, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 360, 50));

        jDateChooser2.setBackground(new java.awt.Color(255, 255, 255));
        jDateChooser2.setDateFormatString("yyyy MMM d");
        jPanel17.add(jDateChooser2, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 220, 197, 33));
        jPanel17.add(jTextField21, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 350, 197, 33));

        jRadioButton3.setText("Oui");
        jRadioButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton3ActionPerformed(evt);
            }
        });
        jPanel17.add(jRadioButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 310, -1, -1));

        jRadioButton4.setText("Non");
        jRadioButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton4ActionPerformed(evt);
            }
        });
        jPanel17.add(jRadioButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 310, -1, -1));

        jLabel74.setText("Localisation:");
        jPanel17.add(jLabel74, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 210, -1, -1));

        jLabel75.setText("Date:");
        jPanel17.add(jLabel75, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 200, -1, -1));

        jLabel76.setText("Etats:");
        jPanel17.add(jLabel76, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 110, -1, -1));

        jButton47.setBackground(new java.awt.Color(255, 255, 255));
        jButton47.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/backspace.png"))); // NOI18N
        jButton47.setText(" Effacer Tout ");
        jButton47.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        jButton47.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton47ActionPerformed(evt);
            }
        });
        jPanel17.add(jButton47, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 420, -1, -1));

        jButton48.setBackground(new java.awt.Color(255, 255, 255));
        jButton48.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cancel.png"))); // NOI18N
        jButton48.setText(" Annuler ");
        jButton48.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        jButton48.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton48ActionPerformed(evt);
            }
        });
        jPanel17.add(jButton48, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 420, -1, -1));

        jButton49.setBackground(new java.awt.Color(255, 255, 255));
        jButton49.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/save-icon_45x45.png"))); // NOI18N
        jButton49.setText(" Save ");
        jButton49.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        jButton49.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton49ActionPerformed(evt);
            }
        });
        jPanel17.add(jButton49, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 420, -1, -1));

        jLabel77.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/faded blue header.jpg"))); // NOI18N
        jPanel17.add(jLabel77, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 790, 70));

        jLabel78.setText("N° inventaire:");
        jPanel17.add(jLabel78, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, -1, -1));

        jLabel79.setText("Caractéristiques:");
        jPanel17.add(jLabel79, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 290, -1, -1));

        jLabel80.setText("Nom Matériel:");
        jPanel17.add(jLabel80, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, -1, -1));
        jPanel17.add(jTextField23, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 230, 197, 33));
        jPanel17.add(jTextField22, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 120, 197, 33));

        jLabel81.setText("Fournisseur:");
        jPanel17.add(jLabel81, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 100, -1, -1));

        javax.swing.GroupLayout jFrame3Layout = new javax.swing.GroupLayout(jFrame3.getContentPane());
        jFrame3.getContentPane().setLayout(jFrame3Layout);
        jFrame3Layout.setHorizontalGroup(
            jFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jFrame3Layout.setVerticalGroup(
            jFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1350, 710));
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel12.setBackground(new java.awt.Color(153, 153, 153));
        jPanel12.setMaximumSize(new java.awt.Dimension(1350, 710));
        jPanel12.setMinimumSize(new java.awt.Dimension(1350, 710));
        jPanel12.setPreferredSize(new java.awt.Dimension(1350, 710));
        jPanel12.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLayeredPane1.setOpaque(false);
        //jLayeredPane1.setBorder(new RoundedBorder(jPanel12.getBackground(), 00, 00));
        jLayeredPane1.setBackground(new java.awt.Color(255, 255, 255));
        jLayeredPane1.setMaximumSize(new java.awt.Dimension(1019, 669));
        jLayeredPane1.setMinimumSize(new java.awt.Dimension(1019, 669));
        jLayeredPane1.setLayout(new java.awt.CardLayout());

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setMaximumSize(new java.awt.Dimension(1020, 670));
        jPanel3.setMinimumSize(new java.awt.Dimension(1020, 670));
        jPanel3.setPreferredSize(new java.awt.Dimension(1020, 670));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton21.setBackground(new java.awt.Color(0, 176, 255));
        jButton21.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton21.setForeground(new java.awt.Color(255, 255, 255));
        jButton21.setText("Select Image");
        jButton21.setToolTipText("");
        jButton21.setEnabled(false);
        jButton21.setOpaque(false);
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton21, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 370, -1, 50));

        jPanel25.setBackground(new java.awt.Color(173, 186, 230));
        jPanel25.setMaximumSize(new java.awt.Dimension(1103, 83));
        jPanel25.setRequestFocusEnabled(false);
        jPanel25.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel47.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(255, 255, 255));
        jLabel47.setText("User : ViceRecteur");
        jPanel25.add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 380, 60));

        jLabel42.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(255, 255, 255));
        jLabel42.setText("00:00:00");
        jPanel25.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 10, 250, 60));

        jPanel3.add(jPanel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1020, 80));

        jTable9.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null}
            },
            new String [] {
                "Id", "E-Mail", "Img"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable9.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTable9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable9MouseClicked(evt);
            }
        });
        jScrollPane9.setViewportView(jTable9);

        jPanel3.add(jScrollPane9, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 530, 480, 50));

        jButton34.setBackground(new java.awt.Color(255, 255, 255));
        jButton34.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/modifier.png"))); // NOI18N
        jButton34.setText("Edit ");
        jButton34.setBorder(null);
        jButton34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton34ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton34, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 130, -1, -1));

        jLabel44.setText("E-Mail:");
        jPanel3.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 250, -1, -1));

        jTextField14.setEnabled(false);
        jPanel3.add(jTextField14, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 280, 197, 33));

        jLabel45.setText("Password:");
        jPanel3.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 370, -1, -1));

        jLabel48.setText("My information");
        jPanel3.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 550, 90, -1));

        jLabel2.setOpaque(true);
        jLabel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 280, 140, 140));

        jButton32.setBackground(new java.awt.Color(255, 255, 255));
        jButton32.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/save-icon_45x45.png"))); // NOI18N
        jButton32.setText("Save ");
        jButton32.setBorder(null);
        jButton32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton32ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton32, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 130, -1, -1));

        jPasswordField1.setText("jPasswordField1");
        jPasswordField1.setEnabled(false);
        jPanel3.add(jPasswordField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 390, 200, 40));

        jLayeredPane1.add(jPanel3, "card2");

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));
        jPanel9.setMaximumSize(new java.awt.Dimension(1020, 670));
        jPanel9.setMinimumSize(new java.awt.Dimension(1020, 670));
        jPanel9.setPreferredSize(new java.awt.Dimension(1020, 670));
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton5.setBackground(new java.awt.Color(255, 255, 255));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/add.png"))); // NOI18N
        jButton5.setText("Add");
        jButton5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        jButton5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 110, 80, -1));

        jLabel8.setText("Total of materials :");
        jPanel9.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, -1, -1));

        jLabel13.setForeground(new java.awt.Color(255, 51, 51));
        jLabel13.setText("0");
        jPanel9.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 150, -1, -1));

        jButton38.setBackground(new java.awt.Color(255, 255, 255));
        jButton38.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/import-file-icon.png"))); // NOI18N
        jButton38.setText("Import File ");
        jButton38.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        jButton38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton38ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton38, new org.netbeans.lib.awtextra.AbsoluteConstraints(655, 110, -1, -1));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Nom Matériel", "N° inventaire", "Caractéristiques", "Etats", "Date mise en service", "Consommable", "Description", "Affecté", "Fournisseur", "Localisation"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.setOpaque(false);
        jTable1.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel9.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 940, 470));

        jPanel19.setBackground(new java.awt.Color(173, 186, 230));
        jPanel19.setMaximumSize(new java.awt.Dimension(1103, 83));
        jPanel19.setMinimumSize(new java.awt.Dimension(1103, 83));
        jPanel19.setPreferredSize(new java.awt.Dimension(1103, 83));
        jPanel19.setRequestFocusEnabled(false);
        jPanel19.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Nom Matériel", "N°inventaire", "Caractéristiques" }));
        jComboBox5.setOpaque(false);
        jComboBox5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox5ActionPerformed(evt);
            }
        });
        jPanel19.add(jComboBox5, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 20, 110, 40));

        jButton1.setBackground(new java.awt.Color(0, 176, 255));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/sign-sync-icon_45x45.png"))); // NOI18N
        jButton1.setBorder(null);
        jButton1.setOpaque(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel19.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 20, 45, 45));

        jTextField7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField7ActionPerformed(evt);
            }
        });
        jPanel19.add(jTextField7, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 20, 250, 40));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Searched by :");
        jPanel19.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 30, -1, -1));

        jLabel36.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setText("Stock management");
        jPanel19.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 15, 230, 50));

        jPanel9.add(jPanel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1020, -1));

        jButton12.setBackground(new java.awt.Color(255, 255, 255));
        jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/delete_icon_45x45.png"))); // NOI18N
        jButton12.setText("Delete ");
        jButton12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        jButton12.setEnabled(false);
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 110, -1, -1));

        jButton51.setBackground(new java.awt.Color(255, 255, 255));
        jButton51.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/modifier.png"))); // NOI18N
        jButton51.setText("Edit ");
        jButton51.setBorder(null);
        jButton51.setEnabled(false);
        jButton51.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton51ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton51, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 110, -1, -1));

        jLayeredPane1.add(jPanel9, "card8");

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setMaximumSize(new java.awt.Dimension(1020, 670));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/schemauniv2.png"))); // NOI18N
        jLabel12.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jLabel12MouseMoved(evt);
            }
        });
        jLabel12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel12MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel12MouseExited(evt);
            }
        });
        jPanel4.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 100, 940, 540));

        jLabel89.setFont(new java.awt.Font("Roboto Condensed", 0, 36)); // NOI18N
        jLabel89.setText("University of Ain Témouchent (BELHADJ Bouchaib)");
        jPanel4.add(jLabel89, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 0, 790, 110));

        jLabel3.setOpaque(true);
        jLabel3.setBorder(new RoundedBorder(jPanel12.getBackground(), 50, 00));
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/accueil.jpeg"))); // NOI18N
        jLabel3.setMaximumSize(new java.awt.Dimension(1020, 670));
        jLabel3.setMinimumSize(new java.awt.Dimension(1020, 670));
        jLabel3.setPreferredSize(new java.awt.Dimension(1020, 670));
        jPanel4.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLayeredPane1.add(jPanel4, "card3");

        jPanel15.setBackground(new java.awt.Color(255, 255, 255));
        jPanel15.setMaximumSize(new java.awt.Dimension(1020, 670));
        jPanel15.setMinimumSize(new java.awt.Dimension(1020, 670));
        jPanel15.setPreferredSize(new java.awt.Dimension(1020, 670));
        jPanel15.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable11.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Référence", "Nom Matériel", "N° inventaire", "Caractéristiques", "Etats", "Date mise en service", "Consommable", "Description", "Localisation"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable11.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTable11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable11MouseClicked(evt);
            }
        });
        jScrollPane13.setViewportView(jTable11);

        jPanel15.add(jScrollPane13, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 120, 830, 530));

        jPanel27.setBackground(new java.awt.Color(173, 186, 230));
        jPanel27.setMaximumSize(new java.awt.Dimension(1103, 83));
        jPanel27.setRequestFocusEnabled(false);
        jPanel27.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel68.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel68.setForeground(new java.awt.Color(255, 255, 255));
        jLabel68.setText("Searched by :");
        jPanel27.add(jLabel68, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 30, -1, -1));

        jComboBox10.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Nom Matériel", "N°inventaire", "Caractéristiques" }));
        jComboBox10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox10ActionPerformed(evt);
            }
        });
        jPanel27.add(jComboBox10, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 20, 110, 40));

        jButton43.setBackground(new java.awt.Color(0, 176, 255));
        jButton43.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/sign-sync-icon_45x45.png"))); // NOI18N
        jButton43.setBorder(null);
        jButton43.setOpaque(false);
        jButton43.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton43ActionPerformed(evt);
            }
        });
        jPanel27.add(jButton43, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 15, 45, 45));

        jTextField17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField17ActionPerformed(evt);
            }
        });
        jPanel27.add(jTextField17, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 20, 250, 40));

        jLabel58.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel58.setForeground(new java.awt.Color(255, 255, 255));
        jLabel58.setText("Scientific Research materials");
        jPanel27.add(jLabel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 15, 270, 50));

        jPanel15.add(jPanel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1020, 80));

        jLabel33.setForeground(new java.awt.Color(255, 51, 51));
        jLabel33.setText("0");
        jPanel15.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 100, -1, -1));

        jButton44.setBackground(new java.awt.Color(255, 255, 255));
        jButton44.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/delete_icon_45x45.png"))); // NOI18N
        jButton44.setText("Delete ");
        jButton44.setBorder(null);
        jButton44.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton44ActionPerformed(evt);
            }
        });
        jPanel15.add(jButton44, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 210, -1, -1));

        jLabel69.setText("Total of materials :");
        jPanel15.add(jLabel69, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 100, -1, -1));

        jLayeredPane1.add(jPanel15, "card6");

        jPanel11.setBackground(new java.awt.Color(255, 255, 255));
        jPanel11.setMaximumSize(new java.awt.Dimension(1020, 670));
        jPanel11.setMinimumSize(new java.awt.Dimension(1020, 670));
        jPanel11.setPreferredSize(new java.awt.Dimension(1020, 670));
        jPanel11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel26.setBackground(new java.awt.Color(173, 186, 230));
        jPanel26.setMaximumSize(new java.awt.Dimension(1103, 83));
        jPanel26.setRequestFocusEnabled(false);
        jPanel26.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel65.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel65.setForeground(new java.awt.Color(255, 255, 255));
        jLabel65.setText("Searched by :");
        jPanel26.add(jLabel65, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 30, -1, -1));

        jComboBox9.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Nom Matériel", "N°inventaire", "Caractéristiques" }));
        jComboBox9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox9ActionPerformed(evt);
            }
        });
        jPanel26.add(jComboBox9, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 20, 110, 40));

        jButton35.setBackground(new java.awt.Color(0, 176, 255));
        jButton35.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/sign-sync-icon_45x45.png"))); // NOI18N
        jButton35.setBorder(null);
        jButton35.setOpaque(false);
        jButton35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton35ActionPerformed(evt);
            }
        });
        jPanel26.add(jButton35, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 15, 45, 45));

        jTextField13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField13ActionPerformed(evt);
            }
        });
        jPanel26.add(jTextField13, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 20, 250, 40));

        jLabel82.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel82.setForeground(new java.awt.Color(255, 255, 255));
        jLabel82.setText("Office Furniture");
        jPanel26.add(jLabel82, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 15, 270, 50));

        jPanel11.add(jPanel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1020, 80));

        jTable10.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Référence", "Nom Matériel", "N° inventaire", "Caractéristiques", "Etats", "Date mise en service", "Consommable", "Description", "Localisation"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable10.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTable10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable10MouseClicked(evt);
            }
        });
        jScrollPane10.setViewportView(jTable10);

        jPanel11.add(jScrollPane10, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 120, 830, 530));

        jLabel38.setForeground(new java.awt.Color(255, 51, 51));
        jLabel38.setText("0");
        jPanel11.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 100, -1, -1));

        jButton36.setBackground(new java.awt.Color(255, 255, 255));
        jButton36.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/delete_icon_45x45.png"))); // NOI18N
        jButton36.setText("delete ");
        jButton36.setBorder(null);
        jButton36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton36ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton36, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 210, -1, -1));

        jLabel66.setText("Total of materials :");
        jPanel11.add(jLabel66, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 100, -1, -1));

        jLayeredPane1.add(jPanel11, "card7");

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setMaximumSize(new java.awt.Dimension(1020, 670));
        jPanel6.setMinimumSize(new java.awt.Dimension(1020, 670));
        jPanel6.setPreferredSize(new java.awt.Dimension(1020, 670));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel21.setBackground(new java.awt.Color(173, 186, 230));
        jPanel21.setMaximumSize(new java.awt.Dimension(1103, 83));
        jPanel21.setRequestFocusEnabled(false);
        jPanel21.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel62.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel62.setForeground(new java.awt.Color(255, 255, 255));
        jLabel62.setText("Searched by :");
        jPanel21.add(jLabel62, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 30, -1, -1));

        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Nom Matériel", "N°inventaire", "Caractéristiques" }));
        jComboBox6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox6ActionPerformed(evt);
            }
        });
        jPanel21.add(jComboBox6, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 20, 110, 40));

        jButton22.setBackground(new java.awt.Color(0, 176, 255));
        jButton22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/sign-sync-icon_45x45.png"))); // NOI18N
        jButton22.setBorder(null);
        jButton22.setOpaque(false);
        jButton22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton22ActionPerformed(evt);
            }
        });
        jPanel21.add(jButton22, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 20, 45, 45));

        jTextField9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField9ActionPerformed(evt);
            }
        });
        jPanel21.add(jTextField9, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 20, 250, 40));

        jLabel35.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 255));
        jLabel35.setText("Computer Science materials");
        jPanel21.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 15, 260, 50));

        jPanel6.add(jPanel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1020, 80));

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Référence", "Nom Matériel", "N° inventaire", "Caractéristiques", "Etats", "Date mise en service", "Consommable", "Description", "Localisation"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable4.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTable4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable4MouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(jTable4);

        jPanel6.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 120, 820, 530));

        jButton23.setBackground(new java.awt.Color(255, 255, 255));
        jButton23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/delete_icon_45x45.png"))); // NOI18N
        jButton23.setText("Delete ");
        jButton23.setBorder(null);
        jButton23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton23ActionPerformed(evt);
            }
        });
        jPanel6.add(jButton23, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 220, -1, -1));

        jLabel28.setForeground(new java.awt.Color(255, 51, 51));
        jLabel28.setText("0");
        jPanel6.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 100, -1, -1));

        jLabel61.setText("Total of materials :");
        jPanel6.add(jLabel61, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 100, -1, -1));

        jLayeredPane1.add(jPanel6, "card5");

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setMaximumSize(new java.awt.Dimension(1020, 670));
        jPanel7.setMinimumSize(new java.awt.Dimension(1020, 670));
        jPanel7.setPreferredSize(new java.awt.Dimension(1020, 670));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Référence", "Nom Matériel", "N° inventaire", "Caractéristiques", "Etats", "Date mise en service", "Consommable", "Description", "Localisation"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable5.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTable5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable5MouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(jTable5);

        jPanel7.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 120, 830, 530));

        jPanel22.setBackground(new java.awt.Color(173, 186, 230));
        jPanel22.setMaximumSize(new java.awt.Dimension(1103, 83));
        jPanel22.setRequestFocusEnabled(false);
        jPanel22.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel59.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel59.setForeground(new java.awt.Color(255, 255, 255));
        jLabel59.setText("Searched by :");
        jPanel22.add(jLabel59, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 30, -1, -1));

        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Nom Matériel", "N°inventaire", "Caractéristiques" }));
        jComboBox7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox7ActionPerformed(evt);
            }
        });
        jPanel22.add(jComboBox7, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 20, 110, 40));

        jButton24.setBackground(new java.awt.Color(0, 176, 255));
        jButton24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/sign-sync-icon_45x45.png"))); // NOI18N
        jButton24.setBorder(null);
        jButton24.setOpaque(false);
        jButton24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton24ActionPerformed(evt);
            }
        });
        jPanel22.add(jButton24, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 15, 45, 45));

        jTextField10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField10ActionPerformed(evt);
            }
        });
        jPanel22.add(jTextField10, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 20, 250, 40));

        jLabel43.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(255, 255, 255));
        jLabel43.setText("Scientific materials");
        jPanel22.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 15, 260, 50));

        jPanel7.add(jPanel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1020, 80));

        jLabel32.setForeground(new java.awt.Color(255, 51, 51));
        jLabel32.setText("0");
        jPanel7.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 100, -1, -1));

        jButton25.setBackground(new java.awt.Color(255, 255, 255));
        jButton25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/delete_icon_45x45.png"))); // NOI18N
        jButton25.setText("Delete ");
        jButton25.setBorder(null);
        jButton25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton25ActionPerformed(evt);
            }
        });
        jPanel7.add(jButton25, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 220, -1, -1));

        jLabel60.setText("Total of materials :");
        jPanel7.add(jLabel60, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 100, -1, -1));

        jLayeredPane1.add(jPanel7, "card6");

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));
        jPanel10.setMaximumSize(new java.awt.Dimension(1020, 670));
        jPanel10.setMinimumSize(new java.awt.Dimension(1020, 670));
        jPanel10.setPreferredSize(new java.awt.Dimension(1020, 670));
        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel24.setBackground(new java.awt.Color(173, 186, 230));
        jPanel24.setMaximumSize(new java.awt.Dimension(1103, 83));
        jPanel24.setRequestFocusEnabled(false);
        jPanel24.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel56.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel56.setForeground(new java.awt.Color(255, 255, 255));
        jLabel56.setText("Searched :");
        jPanel24.add(jLabel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 30, -1, -1));

        jButton28.setBackground(new java.awt.Color(0, 176, 255));
        jButton28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/sign-sync-icon_45x45.png"))); // NOI18N
        jButton28.setBorder(null);
        jButton28.setOpaque(false);
        jButton28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton28ActionPerformed(evt);
            }
        });
        jPanel24.add(jButton28, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 20, 45, 45));

        jTextField12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField12ActionPerformed(evt);
            }
        });
        jPanel24.add(jTextField12, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 20, 250, 40));

        jLabel57.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel57.setForeground(new java.awt.Color(255, 255, 255));
        jLabel57.setText("Add Facuties");
        jPanel24.add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 15, 230, 50));

        jPanel10.add(jPanel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1020, 80));

        jPanel23.setBackground(new java.awt.Color(246, 246, 246));

        jTable8.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Id", "Nom Faculté"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable8.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTable8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable8MouseClicked(evt);
            }
        });
        jScrollPane14.setViewportView(jTable8);

        jLabel41.setForeground(new java.awt.Color(255, 51, 51));
        jLabel41.setText("0");

        jLabel11.setText("Total of Faculties:");

        jButton52.setBackground(new java.awt.Color(255, 255, 255));
        jButton52.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/delete_icon_45x45.png"))); // NOI18N
        jButton52.setText("Delete ");
        jButton52.setBorder(null);
        jButton52.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton52ActionPerformed(evt);
            }
        });

        jButton53.setBackground(new java.awt.Color(255, 255, 255));
        jButton53.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/save-icon_45x45.png"))); // NOI18N
        jButton53.setText("Save ");
        jButton53.setBorder(null);
        jButton53.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton53ActionPerformed(evt);
            }
        });

        jButton54.setBackground(new java.awt.Color(255, 255, 255));
        jButton54.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/add.png"))); // NOI18N
        jButton54.setText("Add ");
        jButton54.setBorder(null);
        jButton54.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton54ActionPerformed(evt);
            }
        });

        jTextField4.setEnabled(false);

        jLabel46.setText("Faculty name:");

        jLabel83.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel83.setText("Faculty:");

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jLabel83))
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addComponent(jButton54, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(70, 70, 70)
                        .addComponent(jButton53)
                        .addGap(79, 79, 79)
                        .addComponent(jButton52))
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addGap(163, 163, 163)
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel46)
                            .addGroup(jPanel23Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 174, Short.MAX_VALUE)
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(jLabel11)
                        .addGap(1, 1, 1)
                        .addComponent(jLabel41))
                    .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(60, 60, 60))
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel83)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton54)
                            .addComponent(jButton53)
                            .addComponent(jButton52))
                        .addGap(60, 60, 60)
                        .addComponent(jLabel46)
                        .addGap(14, 14, 14)
                        .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11)
                            .addComponent(jLabel41))
                        .addGap(14, 14, 14)
                        .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(39, Short.MAX_VALUE))
        );

        jPanel10.add(jPanel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 970, 280));

        jLayeredPane1.add(jPanel10, "card9");

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));
        jPanel8.setMaximumSize(new java.awt.Dimension(1020, 670));
        jPanel8.setMinimumSize(new java.awt.Dimension(1020, 670));
        jPanel8.setPreferredSize(new java.awt.Dimension(1020, 670));
        jPanel8.setRequestFocusEnabled(false);
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel29.setBackground(new java.awt.Color(173, 186, 230));
        jPanel29.setMaximumSize(new java.awt.Dimension(1103, 83));
        jPanel29.setRequestFocusEnabled(false);
        jPanel29.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel84.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel84.setForeground(new java.awt.Color(255, 255, 255));
        jLabel84.setText("Searched by :");
        jPanel29.add(jLabel84, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 30, -1, -1));

        jComboBox8.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Nom Matériel", "N°inventaire", "Caractéristiques" }));
        jComboBox8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox8ActionPerformed(evt);
            }
        });
        jPanel29.add(jComboBox8, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 20, 110, 40));

        jButton29.setBackground(new java.awt.Color(0, 176, 255));
        jButton29.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/sign-sync-icon_45x45.png"))); // NOI18N
        jButton29.setBorder(null);
        jButton29.setOpaque(false);
        jButton29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton29ActionPerformed(evt);
            }
        });
        jPanel29.add(jButton29, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 15, 45, 45));

        jTextField11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField11ActionPerformed(evt);
            }
        });
        jPanel29.add(jTextField11, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 20, 250, 40));

        jLabel40.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 255));
        jLabel40.setText("Movement/Maintenance");
        jPanel29.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 15, 230, 50));

        jPanel8.add(jPanel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(1, 1, 1020, 80));

        jTable6.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Nom Matériel", "N° inventaire", "Caractéristiques", "Etats", "Date mise en service", "Consommable", "Description", "Affecté", "Fournisseur", "Localisation"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable6.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTable6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable6MouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(jTable6);

        jPanel8.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(19, 140, 490, 380));

        jLabel24.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel24.setText("Materials");
        jPanel8.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 110, -1, -1));

        jTable13.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Nom Matériel", "N°inventaire", "Caractéristiques", "Affecté", "Localisation", "Nouvelle Localisation", "Cause", "Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable13.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane15.setViewportView(jTable13);

        jPanel8.add(jScrollPane15, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 140, 450, 500));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel14.setText("Select Material");
        jPanel8.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 110, -1, -1));

        jPanel30.setBackground(new java.awt.Color(246, 246, 246));

        jButton31.setBackground(new java.awt.Color(102, 153, 255));
        jButton31.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton31.setForeground(new java.awt.Color(255, 255, 255));
        jButton31.setText("Transfer");
        jButton31.setToolTipText("");
        jButton31.setOpaque(false);
        jButton31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton31ActionPerformed(evt);
            }
        });

        jLabel30.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel30.setText("Cause:");

        jLabel26.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel26.setText("Localisation:");

        javax.swing.GroupLayout jPanel30Layout = new javax.swing.GroupLayout(jPanel30);
        jPanel30.setLayout(jPanel30Layout);
        jPanel30Layout.setHorizontalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel30Layout.createSequentialGroup()
                .addContainerGap(27, Short.MAX_VALUE)
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel30)
                    .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(53, 53, 53)
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel30Layout.createSequentialGroup()
                        .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(63, 63, 63)
                        .addComponent(jButton31))
                    .addComponent(jLabel26))
                .addGap(22, 22, 22))
        );
        jPanel30Layout.setVerticalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel30)
                    .addComponent(jLabel26))
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel30Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(jButton31, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel30Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField16)
                            .addComponent(jTextField15))))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jPanel8.add(jPanel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 540, 470, 100));

        jLayeredPane1.add(jPanel8, "card4");

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setMaximumSize(new java.awt.Dimension(1020, 670));
        jPanel5.setMinimumSize(new java.awt.Dimension(1020, 670));
        jPanel5.setPreferredSize(new java.awt.Dimension(1020, 670));
        jPanel5.setRequestFocusEnabled(false);
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("History");
        jPanel5.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 120, -1, -1));

        jTable7.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Reférence", "Nom Matériel", "N° inventaire", "Caractéristiques", "Etats", "Date mise en service", "Consommable", "Description", "Catégorie", "Localisation", "Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable7.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTable7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable7MouseClicked(evt);
            }
        });
        jScrollPane7.setViewportView(jTable7);

        jPanel5.add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 170, 880, 470));

        jPanel20.setBackground(new java.awt.Color(173, 186, 230));
        jPanel20.setMaximumSize(new java.awt.Dimension(1103, 83));
        jPanel20.setRequestFocusEnabled(false);
        jPanel20.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel63.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel63.setForeground(new java.awt.Color(255, 255, 255));
        jLabel63.setText("Searched by :");
        jPanel20.add(jLabel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 30, -1, -1));

        jButton15.setBackground(new java.awt.Color(102, 153, 255));
        jButton15.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton15.setForeground(new java.awt.Color(255, 255, 255));
        jButton15.setText("Assignment history");
        jButton15.setToolTipText("");
        jButton15.setOpaque(false);
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });
        jPanel20.add(jButton15, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 15, -1, 50));

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Nom Matériel", "N°inventaire", "Caractéristiques" }));
        jComboBox4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox4ActionPerformed(evt);
            }
        });
        jPanel20.add(jComboBox4, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 20, 110, 40));

        jButton18.setBackground(new java.awt.Color(0, 176, 255));
        jButton18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/sign-sync-icon_45x45.png"))); // NOI18N
        jButton18.setBorder(null);
        jButton18.setOpaque(false);
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });
        jPanel20.add(jButton18, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 15, 45, 45));

        jTextField8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField8ActionPerformed(evt);
            }
        });
        jPanel20.add(jTextField8, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 20, 250, 40));

        jLabel39.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(255, 255, 255));
        jLabel39.setText("Material Assignment");
        jPanel20.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 15, 230, 50));

        jPanel5.add(jPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(1, 1, 1020, 80));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Nom Matériel", "N° inventaire", "Caractéristiques", "Etats", "Date mise en service", "Consommable", "Description", "Affecté"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable2.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable2);

        jPanel5.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(19, 140, 490, 380));

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel22.setText("Allocated materials");
        jPanel5.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 110, -1, -1));

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nom Matériel", "N°inventaire", "Caractéristiques", "Etats", "Catégorie", "Localisation"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTable3.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane3.setViewportView(jTable3);

        jPanel5.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 140, 450, 380));

        jButton20.setBackground(new java.awt.Color(255, 165, 0));
        jButton20.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton20.setForeground(new java.awt.Color(255, 255, 255));
        jButton20.setText("Reset");
        jButton20.setToolTipText("");
        jButton20.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton20.setOpaque(false);
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton20, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 570, 100, 50));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setText("Select Material");
        jPanel5.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 110, -1, -1));

        jPanel28.setBackground(new java.awt.Color(246, 246, 246));

        jButton19.setBackground(new java.awt.Color(102, 153, 255));
        jButton19.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton19.setForeground(new java.awt.Color(255, 255, 255));
        jButton19.setText("Allocate");
        jButton19.setToolTipText("");
        jButton19.setOpaque(false);
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });

        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Computer Science", "Scientific", "Scientific Research", "Movable" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jLabel29.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel29.setText("Catégorie:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setText("Localisation:");

        javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel28Layout.createSequentialGroup()
                .addContainerGap(31, Short.MAX_VALUE)
                .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel28Layout.createSequentialGroup()
                        .addComponent(jLabel29)
                        .addGap(88, 88, 88)
                        .addComponent(jLabel4))
                    .addGroup(jPanel28Layout.createSequentialGroup()
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(39, 39, 39)
                        .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(49, 49, 49)
                        .addComponent(jButton19)))
                .addGap(22, 22, 22))
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel28Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel29)
                    .addComponent(jLabel4))
                .addGap(3, 3, 3)
                .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton19, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel28Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jPanel5.add(jPanel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 540, 470, 100));

        jButton50.setBackground(new java.awt.Color(255, 255, 255));
        jButton50.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/delete_icon_45x45.png"))); // NOI18N
        jButton50.setText("Delete ");
        jButton50.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        jButton50.setEnabled(false);
        jButton50.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton50ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton50, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 100, -1, -1));

        jLayeredPane1.add(jPanel5, "card4");

        jPanel12.add(jLayeredPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 40, -1, -1));

        jPanel2.setBackground(new java.awt.Color(153, 153, 153));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel67.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Products list.png"))); // NOI18N
        jPanel2.add(jLabel67, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 440, 50, 50));

        jButton39.setBackground(new java.awt.Color(173, 186, 230));
        jButton39.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton39.setForeground(new java.awt.Color(255, 255, 255));
        jButton39.setText("Scientific Research materials");
        jButton39.setAlignmentY(0.0F);
        jButton39.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jButton39.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton39.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton39ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton39, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 440, 250, 45));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/menu.png"))); // NOI18N
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 50, 50));

        jLabel49.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/affect.png"))); // NOI18N
        jPanel2.add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 50, 50));

        jLabel55.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/my profile icon png.png"))); // NOI18N
        jPanel2.add(jLabel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 620, 50, -1));

        jLabel54.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/department.png"))); // NOI18N
        jPanel2.add(jLabel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 560, 50, 50));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/téléchargement_1.png"))); // NOI18N
        jLabel9.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 15, 60, 50));

        jLabel53.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/New product.png"))); // NOI18N
        jPanel2.add(jLabel53, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 50, 50));

        jLabel51.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Products list.png"))); // NOI18N
        jPanel2.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, 50, 50));

        jLabel50.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Products list.png"))); // NOI18N
        jPanel2.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 320, 50, 50));

        jLabel64.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Products list.png"))); // NOI18N
        jPanel2.add(jLabel64, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 500, 50, 50));

        jButton33.setBackground(new java.awt.Color(173, 186, 230));
        jButton33.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton33.setForeground(new java.awt.Color(255, 255, 255));
        jButton33.setText("Office Furniture");
        jButton33.setAlignmentY(0.0F);
        jButton33.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jButton33.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton33.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton33ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton33, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 500, 250, 45));

        jButton16.setBackground(new java.awt.Color(173, 186, 230));
        jButton16.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton16.setForeground(new java.awt.Color(255, 255, 255));
        jButton16.setText("Dashboard");
        jButton16.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jButton16.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton16.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton16, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 80, 250, 45));

        jButton10.setBackground(new java.awt.Color(173, 186, 230));
        jButton10.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jButton10.setForeground(new java.awt.Color(255, 255, 255));
        jButton10.setText("Material Assignment");
        jButton10.setAlignmentY(0.0F);
        jButton10.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jButton10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton10.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 200, 250, 45));

        jButton6.setBackground(new java.awt.Color(173, 186, 230));
        jButton6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("Computer Science materials");
        jButton6.setAlignmentY(0.0F);
        jButton6.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jButton6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 320, 250, 45));

        jButton7.setBackground(new java.awt.Color(173, 186, 230));
        jButton7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setText("Scientific materials");
        jButton7.setAlignmentY(0.0F);
        jButton7.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jButton7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton7.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 380, 250, 45));

        jButton9.setBackground(new java.awt.Color(173, 186, 230));
        jButton9.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jButton9.setForeground(new java.awt.Color(255, 255, 255));
        jButton9.setText("Stock management");
        jButton9.setAlignmentY(0.0F);
        jButton9.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jButton9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton9.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 140, 250, 45));

        jButton11.setBackground(new java.awt.Color(173, 186, 230));
        jButton11.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jButton11.setForeground(new java.awt.Color(255, 255, 255));
        jButton11.setText("Add Faculties");
        jButton11.setAlignmentY(0.0F);
        jButton11.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jButton11.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton11.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 560, 250, 45));

        jButton17.setBackground(new java.awt.Color(173, 186, 230));
        jButton17.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton17.setForeground(new java.awt.Color(255, 255, 255));
        jButton17.setText("My profile");
        jButton17.setAlignmentY(0.0F);
        jButton17.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jButton17.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton17.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton17, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 620, 250, 45));

        jLabel10.setFont(new java.awt.Font("Roboto Condensed", 1, 30)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("EQUILOG");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 10, 110, 60));

        jButton26.setBackground(new java.awt.Color(173, 186, 230));
        jButton26.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jButton26.setForeground(new java.awt.Color(255, 255, 255));
        jButton26.setText("Movement/Maintenance");
        jButton26.setAlignmentY(0.0F);
        jButton26.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jButton26.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton26.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton26ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton26, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 260, 250, 45));

        jLabel52.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/affect.png"))); // NOI18N
        jPanel2.add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 50, 50));

        jLabel1.setOpaque(true);
        jLabel1.setBorder(new RoundedBorder(jLabel1.getBackground(), 50, 00));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/faded blue.jpg"))); // NOI18N
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 330, 670));

        jPanel12.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 326, 670));

        jPanel1.setBorder(new RoundedBorder(jPanel12.getBackground(), 50, 50));
        jPanel1.setBackground(new java.awt.Color(153, 153, 153));
        jPanel1.setOpaque(false);
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel27.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(255, 51, 51));
        jLabel27.setText("0");
        jPanel1.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 10, 30, -1));

        jButton2.setBackground(new java.awt.Color(255, 255, 255));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/disconnect.png"))); // NOI18N
        jButton2.setBorder(null);
        jButton2.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        jButton2.setOpaque(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1190, 0, 40, 40));

        jButton4.setBackground(new java.awt.Color(255, 255, 255));
        jButton4.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/min.png"))); // NOI18N
        jButton4.setBorder(null);
        jButton4.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        jButton4.setOpaque(false);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1235, 0, 40, 40));

        jButton3.setBackground(new java.awt.Color(255, 255, 255));
        jButton3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ext.png"))); // NOI18N
        jButton3.setBorder(null);
        jButton3.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        jButton3.setOpaque(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 0, 40, 40));

        jButton37.setBackground(new java.awt.Color(153, 153, 153));
        jButton37.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/msg (1).png"))); // NOI18N
        jButton37.setBorder(null);
        jButton37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton37ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton37, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, -1));

        jLabel25.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setText("Vice Recteur");
        jPanel1.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 10, -1, -1));

        jPanel12.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1350, -1));

        getContentPane().add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    String idM3;
    int IDM3;
    int tour = 0;
    int tour2 = 0;
    String ref, cat;
    int REF;

    ArrayList<String> items = new ArrayList<>();
    String[] additionalItems = new String[]{"VRP", "VRPG", "SG", "Facultés"};

    String nomMat2;
    String num2;
    String carac2;
    String etats2;
    String date2;
    String Cons2;
    String Desc2;
    String Aff,Loca;

    String idM;
    int IDM;

    String User, F;

    private void jButton42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton42ActionPerformed

        String Query = " DELETE FROM pfe_schema.messagerie_viserecteur;";

        try {
            // Disable auto-commit mode
            con.setAutoCommit(false);

            st = con.createStatement();
            st.executeUpdate(Query);

            // Commit the transaction
            con.commit();

            // Re-enable auto-commit mode
            con.setAutoCommit(true);

            loadMessagerie();

        } catch (SQLException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

            // Rollback the transaction on error
            try {
                con.rollback();
            } catch (SQLException ex2) {
                Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
            }
        } catch (Exception e) {
            System.out.print("exp :" + e);
        }
    }//GEN-LAST:event_jButton42ActionPerformed

    private void jButton40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton40ActionPerformed

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();

        if ("Recteur".equals(User)) {

            String Query = " INSERT INTO pfe_schema.messagerie_recteur (Utilisateur,message,Date)  "
                    + " VALUES ('"
                    + "Vise Recteur',"
                    + "'" + jTextArea1.getText() + "'"
                    + ", '" + dtf.format(now) + "'); ";

            try {
                // Disable auto-commit mode
                con.setAutoCommit(false);

                st = con.createStatement();
                st.executeUpdate(Query);

                // Commit the transaction
                con.commit();

                // Re-enable auto-commit mode
                con.setAutoCommit(true);

                JOptionPane.showMessageDialog(null, "Message Envoye!", "Message", JOptionPane.INFORMATION_MESSAGE);

            } catch (SQLException ex) {
                Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                // Rollback the transaction on error
                try {
                    con.rollback();
                } catch (SQLException ex2) {
                    Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                }
            } catch (Exception e) {
                System.out.print("exp :" + e);
                JOptionPane.showMessageDialog(null, "Une erreur est survenue!", "Erreur", JOptionPane.ERROR_MESSAGE);
            }

        } else if ("Doyen".equals(User)) {
            String Query = " INSERT INTO pfe_schema.messagerie_doyen (Utilisateur,message,Date,faculte) "
                    + " VALUES ('"
                    + "Vise Recteur',"
                    + "'" + jTextArea1.getText() + "'"
                    + ", '" + dtf.format(now) + "'"
                    + ", '" + F + "'); ";

            try {
                // Disable auto-commit mode
                con.setAutoCommit(false);

                st = con.createStatement();
                st.executeUpdate(Query);

                // Commit the transaction
                con.commit();

                // Re-enable auto-commit mode
                con.setAutoCommit(true);

                JOptionPane.showMessageDialog(null, "Message Envoye!", "Message", JOptionPane.INFORMATION_MESSAGE);

            } catch (SQLException ex) {
                Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                // Rollback the transaction on error
                try {
                    con.rollback();
                } catch (SQLException ex2) {
                    Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                }
            } catch (Exception e) {
                System.out.print("exp :" + e);
                JOptionPane.showMessageDialog(null, "Une erreur est survenue!", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        } else if ("SG".equals(User)) {
            String Query = " INSERT INTO pfe_schema.messagerie_sg (Utilisateur,message,Date)  "
                    + " VALUES ('"
                    + "Recteur',"
                    + "'" + jTextArea1.getText() + "'"
                    + ", '" + dtf.format(now) + "'); ";

            try {
                // Disable auto-commit mode
                con.setAutoCommit(false);

                st = con.createStatement();
                st.executeUpdate(Query);

                // Commit the transaction
                con.commit();

                // Re-enable auto-commit mode
                con.setAutoCommit(true);

                JOptionPane.showMessageDialog(null, "Message Envoye!", "Message", JOptionPane.INFORMATION_MESSAGE);

            } catch (SQLException ex) {
                Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                // Rollback the transaction on error
                try {
                    con.rollback();
                } catch (SQLException ex2) {
                    Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                }
            } catch (Exception e) {
                System.out.print("exp :" + e);
                JOptionPane.showMessageDialog(null, "Une erreur est survenue!", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_jButton40ActionPerformed

    private void jButton41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton41ActionPerformed
        jLayeredPane2.removeAll();
        jLayeredPane2.add(jPanel13);
        jLayeredPane2.repaint();
        jLayeredPane2.revalidate();

        loadMessagerie();
    }//GEN-LAST:event_jButton41ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        jLayeredPane2.removeAll();
        jLayeredPane2.add(jPanel14);
        jLayeredPane2.repaint();
        jLayeredPane2.revalidate();

        User = "Recteur";
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        jFrame1.setVisible(false);
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed

        // Create a file chooser dialog
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setCurrentDirectory(new File("C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/"));
        int result = fileChooser.showOpenDialog(null);

        // If the user selects a file, load the image and display it in the JLabel
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try {
                BufferedImage image = ImageIO.read(file);
                jLabel2.setIcon(new ImageIcon(image));
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }//GEN-LAST:event_jButton21ActionPerformed

    private void jTable9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable9MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable9MouseClicked

    private void jButton34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton34ActionPerformed
        jTextField14.setEnabled(true);
        jPasswordField1.setEnabled(true);
        jButton21.setEnabled(true);
    }//GEN-LAST:event_jButton34ActionPerformed

    private void jButton32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton32ActionPerformed

        // Get the image icon from the JLabel
        ImageIcon imageIcon = (ImageIcon) jLabel2.getIcon();

        // Save the image to a temporary file
        File tempFile = null;
        try {
            tempFile = File.createTempFile("tempImage", ".png");
            ImageIO.write((RenderedImage) imageIcon.getImage(), "png", tempFile);
        } catch (IOException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        }

        // Copy the temporary file to the MySQL upload directory
        String newImagePath = "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/" + tempFile.getName();
        File outputFile = new File(newImagePath);
        try {
            Files.copy(tempFile.toPath(), outputFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        }

        String query = "UPDATE pfe_schema.profil_viserecteur "
                + "SET email = ?, "
                + "mdp = ?, "
                + "Img = LOAD_FILE(?) "
                + "WHERE id = ?";

        try {
            // Disable auto-commit mode
            con.setAutoCommit(false);

            PreparedStatement pstmt = con.prepareStatement(query);
            pstmt.setString(1, jTextField14.getText()); // Set the email value
            pstmt.setString(2, jPasswordField1.getText()); // Set the password value
            pstmt.setString(3, newImagePath); // Set the image file path
            pstmt.setInt(4, 1); // Set the row ID to update
            pstmt.executeUpdate();

            // Commit the transaction
            con.commit();

            // Re-enable auto-commit mode
            con.setAutoCommit(true);

            loadDB(12);

            // Delete the image file from the MySQL upload directory
            String newImagePath2 = "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/" + tempFile.getName();
            File outputFile2 = new File(newImagePath2);
            if (outputFile2.exists()) {
                outputFile2.delete();
            }

            JOptionPane.showMessageDialog(null, "Données Enregistre avec Succès", "Message", JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

            // Rollback the transaction on error
            try {
                con.rollback();
            } catch (SQLException ex2) {
                Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
            }
        } catch (Exception e) {
            System.out.print("exp :" + e);
            JOptionPane.showMessageDialog(null, "Une erreur est survenue!", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton32ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        f1 f = new f1();
        f.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        this.setExtendedState(UT1.ICONIFIED);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton37ActionPerformed
        jFrame1.setVisible(true);
        jFrame1.setLocationRelativeTo(null);
        ImageIcon icon = new ImageIcon(getClass().getResource("/images/msg (1).png"));
        jFrame1.setIconImage(icon.getImage());

        loadMessagerie();
    }//GEN-LAST:event_jButton37ActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
        jLayeredPane2.removeAll();
        jLayeredPane2.add(jPanel14);
        jLayeredPane2.repaint();
        jLayeredPane2.revalidate();

        User = "Doyen";
        F = "st";
    }//GEN-LAST:event_jMenuItem4ActionPerformed

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
        jLayeredPane2.removeAll();
        jLayeredPane2.add(jPanel14);
        jLayeredPane2.repaint();
        jLayeredPane2.revalidate();

        User = "Doyen";
        F = "droit";
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
        jLayeredPane2.removeAll();
        jLayeredPane2.add(jPanel14);
        jLayeredPane2.repaint();
        jLayeredPane2.revalidate();

        User = "Doyen";
        F = "segsh";
    }//GEN-LAST:event_jMenuItem6ActionPerformed

    private void jMenuItem7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem7ActionPerformed
        jLayeredPane2.removeAll();
        jLayeredPane2.add(jPanel14);
        jLayeredPane2.repaint();
        jLayeredPane2.revalidate();

        User = "Doyen";
        F = "llsh";
    }//GEN-LAST:event_jMenuItem7ActionPerformed

    private void jMenuItem8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem8ActionPerformed
        jLayeredPane2.removeAll();
        jLayeredPane2.add(jPanel14);
        jLayeredPane2.repaint();
        jLayeredPane2.revalidate();

        User = "SG";
    }//GEN-LAST:event_jMenuItem8ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

        jFrame2.setVisible(true);
        jFrame2.setLocationRelativeTo(null);

        jTextField1.setEnabled(true);
        jTextField2.setEnabled(true);
        jTextField3.setEnabled(true);
        jTextField6.setEnabled(true);
        jComboBox3.setEnabled(true);
        jTextField5.setEnabled(true);
        jDateChooser1.setEnabled(true);
        jRadioButton1.setEnabled(true);
        jRadioButton1.setSelected(true);
        jTextField5.setVisible(true);
        jRadioButton2.setEnabled(true);
        jRadioButton2.setSelected(false);

        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.insertRow(jTable1.getRowCount(), new Object[]{"", "", "", "", "", "", ""});

        jTextField1.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField6.setText("");
        jTextField5.setText("");
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton38ActionPerformed

        JFileChooser chooser = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Excel files", "xls", "xlsx");
        chooser.setFileFilter(filter);
        int returnVal = chooser.showOpenDialog(null);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();

            // Read the Excel file and insert its data into a MySQL table
            try {
                // Get the workbook instance for the file
                XSSFWorkbook workbook = new XSSFWorkbook(file);

                // Get the first sheet from the workbook
                XSSFSheet sheet = workbook.getSheetAt(0);

                // Skip the first row (header row)
                Iterator<Row> rowIterator = sheet.iterator();

                if (rowIterator.hasNext()) {
                    rowIterator.next(); // skip the first row
                }

                int ic = 0;
                while (rowIterator.hasNext()) {
                    Row row = rowIterator.next();
                    // Iterate through each cell of the row
                    ic++;
                    //System.out.print("i = " + ic + "\t");
                    for (Cell cell : row) {
                        // Print the value of the cell
                        //System.out.print(cell.toString() + "\t");
                    }
                    //System.out.println();

                    // Extract the data from the row
                    String nomMateriel = row.getCell(0).getStringCellValue();
                    String numInventaire = row.getCell(1).getStringCellValue();
                    String caracteristiques = row.getCell(2).getStringCellValue();
                    String etats = row.getCell(3).getStringCellValue();

                    // Create a DataFormatter with a specific Locale
                    DataFormatter formatter = new DataFormatter();

                    // Get the date value as a string using the formatter
                    String dateStr = formatter.formatCellValue(row.getCell(4));

                    DateFormat dateFormat = new SimpleDateFormat("M/d/yy");
                    Date dateMiseEnService = dateFormat.parse(dateStr);
                    //System.out.println("\n DateFormat date: " + dateMiseEnService);

                    //DateFormat mysqlDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    DateFormat mysqlDateFormat = new SimpleDateFormat("yy-MM-dd");
                    String mysqlDate = mysqlDateFormat.format(dateMiseEnService);
                    //System.out.println("\n mysqlDate date: " + mysqlDate);

                    String consommable = row.getCell(5).getStringCellValue();
                    String description = row.getCell(6).getStringCellValue();
                    String affecte = row.getCell(7).getStringCellValue();
                    String fournisseur = row.getCell(8).getStringCellValue();
                    String Loca = row.getCell(9).getStringCellValue();

                    // Create an INSERT statement for inserting the data into the MySQL table
                    String sql = String.format("INSERT INTO pfe_schema.stock (NomMatériel, N°inventaire, Caractéristiques, Etats, DateMiseEnService, Consommable, Description, Affecté, Fournisseur, Localisation)"
                            + " VALUES ('%s',"
                            + "'%s', "
                            + "'%s', "
                            + "'%s', "
                            + "'%s', "
                            + "'%s', "
                            + "'%s', "
                            + "'%s', "
                            + "'%s', "
                            + "'%s')", nomMateriel, numInventaire, caracteristiques, etats, mysqlDate, consommable, description, affecte, fournisseur, Loca);

                    // Disable auto-commit mode
                    con.setAutoCommit(false);

                    st = con.createStatement();
                    st.executeUpdate(sql);

                    // Commit the transaction
                    con.commit();

                    // Re-enable auto-commit mode
                    con.setAutoCommit(true);
                }
                loadDB(1);
                calculateTotal(1);
                // Display a message box to indicate that the data has been imported
                JOptionPane.showMessageDialog(null, "Data imported successfully!");
            } catch (SQLException ex) {
                Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                // Rollback the transaction on error
                try {
                    con.rollback();
                } catch (SQLException ex2) {
                    Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                }
            } catch (Exception ex) {
                // Display an error message if something goes wrong
                System.out.print("exp :" + ex);
                JOptionPane.showMessageDialog(null, "Error importing data: " + ex.getMessage());
            }
        }
    }//GEN-LAST:event_jButton38ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        /*jTextField1.setEnabled(true);
        jTextField2.setEnabled(true);
        jTextField3.setEnabled(true);
        jTextField6.setEnabled(true);
        jComboBox3.setEnabled(true);
        jTextField5.setEnabled(true);
        jDateChooser1.setEnabled(true);
        jRadioButton1.setEnabled(true);
        jRadioButton2.setEnabled(true);*/
        jButton12.setEnabled(true);
        jButton51.setEnabled(true);

        int row = jTable1.getSelectedRow();

        idM = (String) jTable1.getValueAt(row, 0);
        IDM = Integer.parseInt(idM);
        String nomMat = (String) jTable1.getValueAt(row, 1);
        String num = (String) jTable1.getValueAt(row, 2);
        String carac = (String) jTable1.getValueAt(row, 3);
        String etats = (String) jTable1.getValueAt(row, 4);
        String date = (String) jTable1.getValueAt(row, 5);
        String Cons = (String) jTable1.getValueAt(row, 6);
        String F = (String) jTable1.getValueAt(row, 8);

        if ("Oui".equals(Cons) && tour == 0) {
            jRadioButton1.setSelected(true);
            jRadioButton2.setSelected(false);
            jTextField5.setVisible(true);
        } else if ("Non".equals(Cons)) {
            jRadioButton2.setSelected(true);
            jRadioButton1.setSelected(false);
            jTextField5.setVisible(false);
        }

        jTextField1.setText(nomMat);
        jTextField2.setText(num);
        jTextField3.setText(carac);
        jTextField6.setText(F);
        jComboBox3.setSelectedItem(etats);

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date date1 = null;
        try {
            date1 = formatter.parse(date);
        } catch (ParseException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        }
        jDateChooser1.setDate(date1);

        String Desc = (String) jTable1.getValueAt(row, 7);
        jTextField5.setText(Desc);
    }//GEN-LAST:event_jTable1MouseClicked

    private void jComboBox5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox5ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            loadDB(1);
            calculateTotal(1);
        } catch (SQLException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTextField7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField7ActionPerformed

        if (jComboBox5.getSelectedItem() == "Nom Matériel") {
            String txtR = jTextField7.getText();
            String Query = "SELECT * FROM pfe_schema.stock WHERE NomMatériel LIKE '%" + txtR + "%';";
            try {
                ResultSet rs = null;

                st = con.createStatement();
                rs = st.executeQuery(Query);

                DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11)});
                }
                calculateTotal(1);
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        } else if (jComboBox5.getSelectedItem() == "N°inventaire") {
            String numI = jTextField7.getText();

            String Query = "SELECT * FROM pfe_schema.stock WHERE N°inventaire LIKE '%" + numI + "%';";
            try {
                ResultSet rs = null;

                st = con.createStatement();
                rs = st.executeQuery(Query);

                DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11)});
                }
                calculateTotal(1);
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        } else if (jComboBox5.getSelectedItem() == "Caractéristiques") {
            String txtR = jTextField7.getText();
            String Query = "SELECT * FROM pfe_schema.stock WHERE Caractéristiques LIKE '%" + txtR + "%';";
            try {
                ResultSet rs = null;

                st = con.createStatement();
                rs = st.executeQuery(Query);

                DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11)});
                }
                calculateTotal(1);
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        }
    }//GEN-LAST:event_jTextField7ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed

        int dialogResult = JOptionPane.showConfirmDialog(null, "Êtes-vous sûr de vouloir supprimer cet enregistrement ?", "Confirmation", JOptionPane.YES_NO_OPTION);
        if (dialogResult == JOptionPane.YES_OPTION) {
            String Query = "DELETE FROM pfe_schema.stock WHERE id = " + IDM + " ;";
            try {
                ResultSet rs = null;

                // Disable auto-commit mode
                con.setAutoCommit(false);

                st = con.createStatement();
                st.executeUpdate(Query);

                // Commit the transaction
                con.commit();

                // Re-enable auto-commit mode
                con.setAutoCommit(true);
                loadDB(1);

            } catch (SQLException ex) {
                Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                // Rollback the transaction on error
                try {
                    con.rollback();
                } catch (SQLException ex2) {
                    Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                }
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        }

    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton51ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton51ActionPerformed
        jFrame3.setVisible(true);
        jFrame3.setLocationRelativeTo(null);

        jTextField20.setText("");
        jTextField18.setText("");
        jTextField19.setText("");
        jTextField21.setText("");
        jTextField22.setText("");
        jTextField23.setText("");
        Date today = new Date();
        jDateChooser2.setDateFormatString("yyyy MMM d");
        jDateChooser2.setDate(today);

        String nomMateriel = "";
        String numInventaire = "";
        String caracteristiques = "";
        String etats = "";
        Date dateMiseEnService = null;
        String consommable = "";
        String description = "";
        String affecte = "";
        String fournisseur = "";
        String localisation = "";

        String query = "SELECT * FROM stock WHERE id = " + IDM;

        try {
            ResultSet rs = st.executeQuery(query);

            if (rs.next()) { // if there is a match
                nomMateriel = rs.getString("NomMatériel");
                numInventaire = rs.getString("N°inventaire");
                caracteristiques = rs.getString("Caractéristiques");
                etats = rs.getString("Etats");
                dateMiseEnService = rs.getDate("DateMiseEnService");
                consommable = rs.getString("Consommable");
                description = rs.getString("Description");
                affecte = rs.getString("Affecté");
                fournisseur = rs.getString("Fournisseur");
                localisation = rs.getString("Localisation");

                // do something with the retrieved values
            } else {
                // no match found
            }
            jTextField20.setText(nomMateriel);
            jTextField18.setText(numInventaire);
            jTextField19.setText(caracteristiques);
            jComboBox11.setSelectedItem(etats); // Set the selected item in the combo box
            jDateChooser2.setDate(dateMiseEnService);
            if (consommable.equals("Oui")) {
                jRadioButton3.setSelected(true);
                jRadioButton4.setSelected(false);
                jTextField21.setText(description);
                jTextField21.setVisible(true);
            } else {
                jRadioButton4.setSelected(true);
                jRadioButton3.setSelected(false);
                jTextField21.setText("");
                jTextField21.setVisible(false);
            }
            jTextField22.setText(fournisseur);
            jTextField23.setText(localisation);

        } catch (SQLException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton51ActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
        if (jRadioButton1.isSelected()) {
            jRadioButton2.setSelected(false);
            jTextField5.setVisible(true);
        }
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void jRadioButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton2ActionPerformed
        if (jRadioButton2.isSelected()) {
            jRadioButton1.setSelected(false);
            jTextField5.setVisible(false);
        }
    }//GEN-LAST:event_jRadioButton2ActionPerformed

    private void jButton45ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton45ActionPerformed
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jComboBox3.setSelectedIndex(0);
        jTextField6.setText("");
        jTextField5.setText("");
    }//GEN-LAST:event_jButton45ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        jFrame2.dispose();
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed

        SimpleDateFormat dcn = new SimpleDateFormat("yyyy-MM-dd");
        String date = dcn.format(jDateChooser1.getDate());

        String tdesc = "";
        String cons = "";
        if (jRadioButton1.isSelected()) {
            tdesc = jTextField5.getText();
            cons = "Oui";
        } else if (jRadioButton2.isSelected()) {
            tdesc = "";
            cons = "Non";
        }

        String nomMateriel = jTextField1.getText();
        String numInventaire = jTextField2.getText();
        String caracteristiques = jTextField3.getText();

        if (nomMateriel.isEmpty() || numInventaire.isEmpty() || caracteristiques.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Un champ est vide", "Erreur", JOptionPane.ERROR_MESSAGE);
        } else {
            String Query = " INSERT INTO pfe_schema.stock ( NomMatériel, N°inventaire, Caractéristiques, Etats, DateMiseEnService, Consommable, Description, Affecté, Fournisseur) "
                    + " VALUES ('"
                    + "" + nomMateriel + "' ,"
                    + " '" + numInventaire + "' ,"
                    + " '" + caracteristiques + "' ,"
                    + " '" + jComboBox3.getSelectedItem() + "' ,"
                    + " '" + date + "' , "
                    + " '" + cons + "' , "
                    + " '" + tdesc + "' , "
                    + " 'Non' , "
                    + " '" + jTextField6.getText() + "' "
                    + " ); ";
            try {
                ResultSet rs = null;

                // Disable auto-commit mode
                con.setAutoCommit(false);

                st = con.createStatement();
                st.executeUpdate(Query);

                // Commit the transaction
                con.commit();

                // Re-enable auto-commit mode
                con.setAutoCommit(true);

                loadDB(1);

                JOptionPane.showMessageDialog(null, "Données Enregistre avec Succès", "Message", JOptionPane.INFORMATION_MESSAGE);

            } catch (SQLException ex) {
                Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                // Rollback the transaction on error
                try {
                    con.rollback();
                } catch (SQLException ex2) {
                    Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                }
            } catch (Exception e) {
                System.out.print("exp :" + e);
                JOptionPane.showMessageDialog(null, "Une erreur est survenue!", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jRadioButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton3ActionPerformed
        if (jRadioButton3.isSelected()) {
            jRadioButton4.setSelected(false);
            jTextField21.setVisible(true);
        }
    }//GEN-LAST:event_jRadioButton3ActionPerformed

    private void jRadioButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton4ActionPerformed
        if (jRadioButton4.isSelected()) {
            jRadioButton3.setSelected(false);
            jTextField21.setVisible(false);
        }
    }//GEN-LAST:event_jRadioButton4ActionPerformed

    private void jButton47ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton47ActionPerformed
        jTextField20.setText("");
        jTextField18.setText("");
        jTextField19.setText("");
        jTextField21.setText("");
        jTextField22.setText("");
        jTextField23.setText("");
        Date today = new Date();
        jDateChooser2.setDateFormatString("yyyy MMM d");
        jDateChooser2.setDate(today);
        jComboBox11.setSelectedIndex(0);
    }//GEN-LAST:event_jButton47ActionPerformed

    private void jButton48ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton48ActionPerformed
        jFrame3.dispose();
    }//GEN-LAST:event_jButton48ActionPerformed

    private void jButton49ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton49ActionPerformed
        SimpleDateFormat dcn = new SimpleDateFormat("yyyy-MM-dd");
        String date = dcn.format(jDateChooser2.getDate());

        String tdesc = "";
        String cons = "";
        if (jRadioButton3.isSelected()) {
            tdesc = jTextField21.getText();
            cons = "Oui";
        } else if (jRadioButton4.isSelected()) {
            tdesc = "";
            cons = "Non";
        }

        String nomMateriel = jTextField20.getText();
        String numInventaire = jTextField18.getText();
        String caracteristiques = jTextField19.getText();

        if (nomMateriel.isEmpty() || numInventaire.isEmpty() || caracteristiques.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Un champ est vide", "Erreur", JOptionPane.ERROR_MESSAGE);
        } else {
            String Query = "UPDATE pfe_schema.stock SET "
                    + "NomMatériel = '" + nomMateriel + "', "
                    + "N°inventaire = '" + numInventaire + "', "
                    + "Caractéristiques = '" + caracteristiques + "', "
                    + "Etats = '" + jComboBox11.getSelectedItem() + "', "
                    + "DateMiseEnService = '" + date + "', "
                    + "Consommable = '" + cons + "', "
                    + "Description = '" + tdesc + "', "
                    + "Fournisseur = '" + jTextField22.getText() + "', "
                    + "Localisation = '" + jTextField23.getText() + "' "
                    + "WHERE id = " + IDM;

            try {
                ResultSet rs = null;

                // Disable auto-commit mode
                con.setAutoCommit(false);

                st = con.createStatement();
                st.executeUpdate(Query);

                // Commit the transaction
                con.commit();

                // Re-enable auto-commit mode
                con.setAutoCommit(true);

                loadDB(1);

                JOptionPane.showMessageDialog(null, "Données Mises à jour avec Succès", "Message", JOptionPane.INFORMATION_MESSAGE);

            } catch (SQLException ex) {
                Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                // Rollback the transaction on error
                try {
                    con.rollback();
                } catch (SQLException ex2) {
                    Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                }
            } catch (Exception e) {
                System.out.print("exp :" + e);
                JOptionPane.showMessageDialog(null, "Une erreur est survenue!", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_jButton49ActionPerformed

    private void jTable11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable11MouseClicked
        int row = jTable11.getSelectedRow();

        idM = (String) jTable11.getValueAt(row, 0);
        IDM = Integer.parseInt(idM);
        ref = (String) jTable11.getValueAt(row, 1);
        REF = Integer.parseInt(ref);
    }//GEN-LAST:event_jTable11MouseClicked

    private void jComboBox10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox10ActionPerformed

    private void jButton43ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton43ActionPerformed
        try {
            loadDB(14);
            calculateTotal(7);
        } catch (SQLException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton43ActionPerformed

    private void jTextField17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField17ActionPerformed
        if (jComboBox10.getSelectedItem() == "Nom Matériel") {
            String txtR = jTextField17.getText();
            String Query = "SELECT * FROM pfe_schema.materielrecherchescientifique WHERE NomMatériel LIKE '%" + txtR + "%';";
            try {
                ResultSet rs = null;

                st = con.createStatement();
                rs = st.executeQuery(Query);

                DefaultTableModel model = (DefaultTableModel) jTable11.getModel();
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10)});
                }
                calculateTotal(7);
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        } else if (jComboBox10.getSelectedItem() == "N°inventaire") {
            String num = jTextField17.getText();

            String Query = "SELECT * FROM pfe_schema.materielrecherchescientifique WHERE N°inventaire LIKE '%" + num + "%';";
            try {
                ResultSet rs = null;

                st = con.createStatement();
                rs = st.executeQuery(Query);

                DefaultTableModel model = (DefaultTableModel) jTable11.getModel();
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10)});
                }
                calculateTotal(7);
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        } else if (jComboBox10.getSelectedItem() == "Caractéristiques") {
            String txtR = jTextField17.getText();
            String Query = "SELECT * FROM pfe_schema.materielrecherchescientifique WHERE Caractéristiques LIKE '%" + txtR + "%';";
            try {
                ResultSet rs = null;

                st = con.createStatement();
                rs = st.executeQuery(Query);

                DefaultTableModel model = (DefaultTableModel) jTable11.getModel();
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10)});
                }
                calculateTotal(7);
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        }
    }//GEN-LAST:event_jTextField17ActionPerformed

    private void jButton44ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton44ActionPerformed
        int dialogResult = JOptionPane.showConfirmDialog(null, "Êtes-vous sûr de vouloir supprimer cet enregistrement ?", "Confirmation", JOptionPane.YES_NO_OPTION);
        if (dialogResult == JOptionPane.YES_OPTION) {
            String QueryUpdate = "UPDATE pfe_schema.stock "
                    + " SET Affecté = 'Non', Localisation = '' "
                    + " WHERE id = " + REF + ";";

            String Query = " DELETE FROM pfe_schema.materielrecherchescientifique "
                    + "WHERE id = " + IDM + " ;";

            try {
                // Disable auto-commit mode
                con.setAutoCommit(false);

                PreparedStatement pstmt = con.prepareStatement(QueryUpdate);
                pstmt.executeUpdate();

                st = con.createStatement();
                st.executeUpdate(Query);

                // Commit the transaction
                con.commit();

                // Re-enable auto-commit mode
                con.setAutoCommit(true);

                loadDB(14);

            } catch (SQLException ex) {
                Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                // Rollback the transaction on error
                try {
                    con.rollback();
                } catch (SQLException ex2) {
                    Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                }
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        }
    }//GEN-LAST:event_jButton44ActionPerformed

    private void jComboBox9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox9ActionPerformed

    private void jButton35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton35ActionPerformed
        try {
            loadDB(13);
            calculateTotal(6);
        } catch (SQLException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton35ActionPerformed

    private void jTextField13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField13ActionPerformed
        if (jComboBox9.getSelectedItem() == "Nom Matériel") {
            String txtR = jTextField13.getText();
            String Query = "SELECT * FROM pfe_schema.materielmobilier WHERE NomMatériel LIKE '%" + txtR + "%';";
            try {
                ResultSet rs = null;

                st = con.createStatement();
                rs = st.executeQuery(Query);

                DefaultTableModel model = (DefaultTableModel) jTable10.getModel();
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10)});
                }
                calculateTotal(6);
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        } else if (jComboBox9.getSelectedItem() == "N°inventaire") {
            String num = jTextField13.getText();

            String Query = "SELECT * FROM pfe_schema.materielmobilier WHERE N°inventaire LIKE '%" + num + "%';";
            try {
                ResultSet rs = null;

                st = con.createStatement();
                rs = st.executeQuery(Query);

                DefaultTableModel model = (DefaultTableModel) jTable10.getModel();
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10)});
                }
                calculateTotal(6);
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        } else if (jComboBox9.getSelectedItem() == "Caractéristiques") {
            String txtR = jTextField13.getText();
            String Query = "SELECT * FROM pfe_schema.materielmobilier WHERE Caractéristiques LIKE '%" + txtR + "%';";
            try {
                ResultSet rs = null;

                st = con.createStatement();
                rs = st.executeQuery(Query);

                DefaultTableModel model = (DefaultTableModel) jTable10.getModel();
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10)});
                }
                calculateTotal(6);
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        }
    }//GEN-LAST:event_jTextField13ActionPerformed

    private void jTable10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable10MouseClicked
        int row = jTable10.getSelectedRow();

        idM = (String) jTable10.getValueAt(row, 0);
        IDM = Integer.parseInt(idM);

        ref = (String) jTable10.getValueAt(row, 1);
        REF = Integer.parseInt(ref);
    }//GEN-LAST:event_jTable10MouseClicked

    private void jButton36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton36ActionPerformed
        int dialogResult = JOptionPane.showConfirmDialog(null, "Êtes-vous sûr de vouloir supprimer cet enregistrement ?", "Confirmation", JOptionPane.YES_NO_OPTION);
        if (dialogResult == JOptionPane.YES_OPTION) {
            String QueryUpdate = "UPDATE pfe_schema.stock "
                    + " SET Affecté = 'Non', Localisation = '' "
                    + " WHERE id = " + REF + ";";

            String Query = " DELETE FROM pfe_schema.materielmobilier "
                    + "WHERE id = " + IDM + " ;";

            try {
                // Disable auto-commit mode
                con.setAutoCommit(false);

                PreparedStatement pstmt = con.prepareStatement(QueryUpdate);
                pstmt.executeUpdate();

                st = con.createStatement();
                st.executeUpdate(Query);

                // Commit the transaction
                con.commit();

                // Re-enable auto-commit mode
                con.setAutoCommit(true);

                loadDB(13);

            } catch (SQLException ex) {
                Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                // Rollback the transaction on error
                try {
                    con.rollback();
                } catch (SQLException ex2) {
                    Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                }
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        }
    }//GEN-LAST:event_jButton36ActionPerformed

    private void jComboBox6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox6ActionPerformed

    private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton22ActionPerformed
        try {
            loadDB(3);
            calculateTotal(2);
        } catch (SQLException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton22ActionPerformed

    private void jTextField9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField9ActionPerformed

        if (jComboBox6.getSelectedItem() == "Nom Matériel") {
            String txtR = jTextField9.getText();
            String Query = "SELECT * FROM pfe_schema.materielinfo WHERE NomMatériel LIKE '%" + txtR + "%';";
            try {
                ResultSet rs = null;

                st = con.createStatement();
                rs = st.executeQuery(Query);

                DefaultTableModel model = (DefaultTableModel) jTable4.getModel();
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10)});
                }
                calculateTotal(2);
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        } else if (jComboBox6.getSelectedItem() == "N°inventaire") {
            String numI = jTextField9.getText();

            String Query = "SELECT * FROM pfe_schema.materielinfo WHERE N°inventaire LIKE '%" + numI + "%';";
            try {
                ResultSet rs = null;

                st = con.createStatement();
                rs = st.executeQuery(Query);

                DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10)});
                }
                calculateTotal(1);
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        } else if (jComboBox6.getSelectedItem() == "Caractéristiques") {
            String txtR = jTextField9.getText();
            String Query = "SELECT * FROM pfe_schema.materielinfo WHERE Caractéristiques LIKE '%" + txtR + "%';";
            try {
                ResultSet rs = null;

                st = con.createStatement();
                rs = st.executeQuery(Query);

                DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10)});
                }
                calculateTotal(1);
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        }
    }//GEN-LAST:event_jTextField9ActionPerformed

    private void jTable4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable4MouseClicked

        int row = jTable4.getSelectedRow();

        idM = (String) jTable4.getValueAt(row, 0);
        IDM = Integer.parseInt(idM);
        ref = (String) jTable4.getValueAt(row, 1);
        REF = Integer.parseInt(ref);
    }//GEN-LAST:event_jTable4MouseClicked

    private void jButton23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton23ActionPerformed

        int dialogResult = JOptionPane.showConfirmDialog(null, "Êtes-vous sûr de vouloir supprimer cet enregistrement ?", "Confirmation", JOptionPane.YES_NO_OPTION);
        if (dialogResult == JOptionPane.YES_OPTION) {

            String QueryUpdate = "UPDATE pfe_schema.stock "
                    + " SET Affecté = 'Non', Localisation = '' "
                    + " WHERE id = " + REF + ";";

            String Query = " DELETE FROM pfe_schema.materielinfo "
                    + "WHERE id = " + IDM + " ;";

            try {
                // Disable auto-commit mode
                con.setAutoCommit(false);

                // Execute the SQL statement within the transaction
                PreparedStatement pstmt = con.prepareStatement(QueryUpdate);
                pstmt.executeUpdate();

                st = con.createStatement();
                st.executeUpdate(Query);

                // Commit the transaction
                con.commit();

                // Re-enable auto-commit mode
                con.setAutoCommit(true);

                loadDB(3);

            } catch (SQLException ex) {
                Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                // Rollback the transaction on error
                try {
                    con.rollback();
                } catch (SQLException ex2) {
                    Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                }
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        }
    }//GEN-LAST:event_jButton23ActionPerformed

    private void jTable5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable5MouseClicked
        int row = jTable5.getSelectedRow();

        idM = (String) jTable5.getValueAt(row, 0);
        IDM = Integer.parseInt(idM);
        ref = (String) jTable5.getValueAt(row, 1);
        REF = Integer.parseInt(ref);
    }//GEN-LAST:event_jTable5MouseClicked

    private void jComboBox7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox7ActionPerformed

    private void jButton24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton24ActionPerformed
        try {
            loadDB(4);
            calculateTotal(3);
        } catch (SQLException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton24ActionPerformed

    private void jTextField10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField10ActionPerformed
        if (jComboBox7.getSelectedItem() == "Nom Matériel") {
            String txtR = jTextField10.getText();
            String Query = "SELECT * FROM pfe_schema.materielscientifique WHERE NomMatériel LIKE '%" + txtR + "%';";
            try {
                ResultSet rs = null;

                st = con.createStatement();
                rs = st.executeQuery(Query);

                DefaultTableModel model = (DefaultTableModel) jTable5.getModel();
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10)});
                }
                calculateTotal(3);
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        } else if (jComboBox7.getSelectedItem() == "N°inventaire") {
            String num = jTextField10.getText();

            String Query = "SELECT * FROM pfe_schema.materielscientifique WHERE N°inventaire LIKE '%" + num + "%';";
            try {
                ResultSet rs = null;

                st = con.createStatement();
                rs = st.executeQuery(Query);

                DefaultTableModel model = (DefaultTableModel) jTable5.getModel();
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10)});
                }
                calculateTotal(3);
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        } else if (jComboBox7.getSelectedItem() == "Caractéristiques") {
            String txtR = jTextField10.getText();
            String Query = "SELECT * FROM pfe_schema.materielscientifique WHERE Caractéristiques LIKE '%" + txtR + "%';";
            try {
                ResultSet rs = null;

                st = con.createStatement();
                rs = st.executeQuery(Query);

                DefaultTableModel model = (DefaultTableModel) jTable5.getModel();
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10)});
                }
                calculateTotal(3);
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        }
    }//GEN-LAST:event_jTextField10ActionPerformed

    private void jButton25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton25ActionPerformed
        int dialogResult = JOptionPane.showConfirmDialog(null, "Êtes-vous sûr de vouloir supprimer cet enregistrement ?", "Confirmation", JOptionPane.YES_NO_OPTION);
        if (dialogResult == JOptionPane.YES_OPTION) {

            String QueryUpdate = "UPDATE pfe_schema.stock "
                    + " SET Affecté = 'Non', Localisation = '' "
                    + " WHERE id = " + REF + ";";

            String Query = " DELETE FROM pfe_schema.materielscientifique "
                    + "WHERE id = " + IDM + " ;";

            try {
                // Disable auto-commit mode
                con.setAutoCommit(false);

                PreparedStatement pstmt = con.prepareStatement(QueryUpdate);
                pstmt.executeUpdate();

                st = con.createStatement();
                st.executeUpdate(Query);

                // Commit the transaction
                con.commit();

                // Re-enable auto-commit mode
                con.setAutoCommit(true);

                loadDB(4);

            } catch (SQLException ex) {
                Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                // Rollback the transaction on error
                try {
                    con.rollback();
                } catch (SQLException ex2) {
                    Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                }
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        }
    }//GEN-LAST:event_jButton25ActionPerformed

    // Create a new JLabel instance with default text.
    JLabel popupLabel = new JLabel();

    // Create a new JWindow instance and set its content pane to the JLabel.
    JWindow popup = new JWindow();
    private void jLabel12MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel12MouseMoved
        // Check if the mouse is inside the label's bounds.
        if (jLabel12.getBounds().contains(evt.getPoint())) {
            // Show the popup if the mouse is inside the label's bounds.
            popup.pack();
            popup.setLocation((jLabel12.getLocationOnScreen().x - 400) + jLabel12.getWidth(), (jLabel12.getLocationOnScreen().y + 90));
            popup.setVisible(true);
            popup.toFront();
        } else {
            // Hide the popup if the mouse is outside the label's bounds.
            popup.setVisible(false);
        }
    }//GEN-LAST:event_jLabel12MouseMoved

    private void jLabel12MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel12MouseEntered

        // Set the font and background color of the JLabel.
        popupLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        popupLabel.setBackground(Color.GRAY);

        popup.getContentPane().add(popupLabel);
        popupLabel.setBackground(Color.GRAY);

        //popup.setLocation(700, 130);
        popup.toFront();

        // Show the popup when the mouse enters the label.
        popup.setVisible(true);
    }//GEN-LAST:event_jLabel12MouseEntered

    private void jLabel12MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel12MouseExited
        // Stop the timer and hide the popup when the mouse leaves the label.
        popup.setVisible(false);
    }//GEN-LAST:event_jLabel12MouseExited

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
        jLayeredPane1.removeAll();
        jLayeredPane1.add(jPanel3);
        jLayeredPane1.repaint();
        jLayeredPane1.revalidate();

        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("hh:mm:ss a");
        Timer timer = new Timer(1000, e -> {
            LocalTime time = LocalTime.now();
            String timeString = time.format(timeFormatter);
            jLabel42.setText(timeString);
        });
        timer.start();

        try {
            loadDB(12);
        } catch (SQLException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton17ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        jLayeredPane1.removeAll();
        jLayeredPane1.add(jPanel10);
        jLayeredPane1.repaint();
        jLayeredPane1.revalidate();
        System.out.print("jPanel10");
        try {
            loadDB(10);
            calculateTotal(5);
        } catch (SQLException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed

        jLayeredPane1.removeAll();
        jLayeredPane1.add(jPanel9);
        jLayeredPane1.repaint();
        jLayeredPane1.revalidate();

        jTextField1.setVisible(true);
        jTextField2.setVisible(true);
        jTextField3.setVisible(true);
        jComboBox3.setVisible(true);
        jTextField6.setVisible(true);
        jTextField5.setVisible(true);
        jDateChooser1.setVisible(true);
        jRadioButton1.setVisible(true);
        jRadioButton2.setVisible(true);;
        jTextField5.setVisible(true);
        jButton13.setVisible(true);
        jButton5.setVisible(true);
        jLabel16.setVisible(true);
        jLabel17.setVisible(true);
        jLabel18.setVisible(true);
        jLabel37.setVisible(true);
        jLabel19.setVisible(true);
        jLabel20.setVisible(true);
        jLabel21.setVisible(true);

        jRadioButton1.setSelected(true);
        jRadioButton2.setSelected(false);
        jTextField5.setVisible(true);

        jButton51.setEnabled(false);
        jButton12.setEnabled(false);

        try {
            loadDB(1);
            calculateTotal(1);
        } catch (Exception e) {
            System.out.print("exp :" + e);
        }
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        jLayeredPane1.removeAll();
        jLayeredPane1.add(jPanel7);
        jLayeredPane1.repaint();
        jLayeredPane1.revalidate();
        System.out.print("jPanel7");
        try {
            loadDB(4);
            calculateTotal(3);
        } catch (SQLException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        jLayeredPane1.removeAll();
        jLayeredPane1.add(jPanel6);
        jLayeredPane1.repaint();
        jLayeredPane1.revalidate();
        System.out.print("jPanel6");
        try {
            loadDB(3);
            calculateTotal(2);
        } catch (SQLException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        jLayeredPane1.removeAll();
        jLayeredPane1.add(jPanel5);
        jLayeredPane1.repaint();
        jLayeredPane1.revalidate();
        System.out.print("jPanel5");
        jButton15.setText("Assignment history");
        jButton15.setBackground(new Color(102, 153, 255));

        jScrollPane7.setVisible(false);
        jButton50.setVisible(false);
        jButton50.setEnabled(false);
        jLabel5.setVisible(false);

        jScrollPane2.setVisible(true);
        jScrollPane3.setVisible(true);
        jLabel4.setVisible(true);
        jLabel22.setVisible(true);
        jLabel6.setVisible(true);
        jComboBox1.setVisible(true);
        jComboBox2.setVisible(true);
        jButton19.setVisible(true);
        jPanel28.setVisible(true);
        jButton20.setVisible(true);

        tour2 = 0;

        try {
            loadDB(2);
            loadDB(9);
            loadDB(11);

            String[] allItems = Arrays.copyOf(items.toArray(new String[0]), items.size() + additionalItems.length);
            System.arraycopy(additionalItems, 0, allItems, items.size(), additionalItems.length);

            DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(allItems);
            jComboBox2.getModel();
            jComboBox2.setModel(model);
        } catch (SQLException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
        jLayeredPane1.removeAll();
        jLayeredPane1.add(jPanel4);
        jLayeredPane1.repaint();
        jLayeredPane1.revalidate();
        try {
            loadDB(40);
        } catch (SQLException ex) {
            Logger.getLogger(Doyen.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Doyen.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton33ActionPerformed
        jLayeredPane1.removeAll();
        jLayeredPane1.add(jPanel11);
        jLayeredPane1.repaint();
        jLayeredPane1.revalidate();
        System.out.print("jPanel11");
        try {
            loadDB(13);
            calculateTotal(6);
        } catch (SQLException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton33ActionPerformed

    private void jButton39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton39ActionPerformed
        jLayeredPane1.removeAll();
        jLayeredPane1.add(jPanel15);
        jLayeredPane1.repaint();
        jLayeredPane1.revalidate();
        System.out.print("jPanel15");
        try {
            loadDB(14);
            calculateTotal(7);
        } catch (SQLException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton39ActionPerformed

    private void jButton28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton28ActionPerformed
        try {
            loadDB(10);
            calculateTotal(5);
        } catch (SQLException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton28ActionPerformed

    private void jTextField12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField12ActionPerformed
        String txtR = jTextField12.getText();
        String Query = "SELECT * FROM pfe_schema.faculte WHERE Nom_Faculté LIKE '%" + txtR + "%';";
        try {
            ResultSet rs = null;

            st = con.createStatement();
            rs = st.executeQuery(Query);

            DefaultTableModel model = (DefaultTableModel) jTable8.getModel();
            model.setRowCount(0);
            while (rs.next()) {
                model.addRow(new String[]{rs.getString(1), rs.getString(2)});
            }
            calculateTotal(5);
        } catch (Exception e) {
            System.out.print("exp :" + e);
        }
    }//GEN-LAST:event_jTextField12ActionPerformed
    String idDep;
    int IDDEP;
    private void jTable8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable8MouseClicked
        jTextField4.setEnabled(true);

        int row = jTable8.getSelectedRow();

        idDep = (String) jTable8.getValueAt(row, 0);
        IDDEP = Integer.parseInt(idDep);
        String nomMat = (String) jTable8.getValueAt(row, 1);

        jTextField4.setText(nomMat);
    }//GEN-LAST:event_jTable8MouseClicked

    private void jButton52ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton52ActionPerformed
        String Query = " DELETE FROM pfe_schema.faculte "
                + "WHERE id = " + IDDEP + " ;";

        try {
            // Disable auto-commit mode
            con.setAutoCommit(false);

            st = con.createStatement();
            st.executeUpdate(Query);

            // Commit the transaction
            con.commit();

            // Re-enable auto-commit mode
            con.setAutoCommit(true);

            loadDB(10);
            calculateTotal(5);

        } catch (SQLException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

            // Rollback the transaction on error
            try {
                con.rollback();
            } catch (SQLException ex2) {
                Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
            }
        } catch (Exception e) {
            System.out.print("exp :" + e);
        }
    }//GEN-LAST:event_jButton52ActionPerformed

    private void jButton53ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton53ActionPerformed
        String Query = " INSERT INTO pfe_schema.faculte (Nom_Faculté) "
                + " VALUES ('"
                + "" + jTextField4.getText() + "' "
                + " ); ";

        try {
            // Disable auto-commit mode
            con.setAutoCommit(false);

            st = con.createStatement();
            st.executeUpdate(Query);

            // Commit the transaction
            con.commit();

            // Re-enable auto-commit mode
            con.setAutoCommit(true);

            loadDB(10);
            calculateTotal(5);

            JOptionPane.showMessageDialog(null, "Données Enregistre avec Succès", "Message", JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

            // Rollback the transaction on error
            try {
                con.rollback();
            } catch (SQLException ex2) {
                Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
            }
        } catch (Exception e) {
            System.out.print("exp :" + e);
            JOptionPane.showMessageDialog(null, "Une Erreur est survenue!", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton53ActionPerformed

    private void jButton54ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton54ActionPerformed
        jTextField4.setEnabled(true);

        DefaultTableModel model = (DefaultTableModel) jTable8.getModel();
        model.insertRow(jTable8.getRowCount(), new Object[]{"", ""});

        jTextField4.setText("");
    }//GEN-LAST:event_jButton54ActionPerformed

    private void jComboBox8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox8ActionPerformed

    private void jButton29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton29ActionPerformed
        try {
            loadDB(71);
            loadDB(70);
        } catch (SQLException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton29ActionPerformed

    private void jTextField11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField11ActionPerformed
        if (jComboBox8.getSelectedItem() == "Nom Matériel") {
            String txtR = jTextField11.getText();
            String Query = "SELECT * FROM pfe_schema.stock WHERE NomMatériel LIKE '%" + txtR + "%' AND Affecté = 'Oui';";

            try {
                ResultSet rs = null;

                st = con.createStatement();
                rs = st.executeQuery(Query);

                DefaultTableModel model = (DefaultTableModel) jTable6.getModel();
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11)});
                }
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        } else if (jComboBox8.getSelectedItem() == "N°inventaire") {
            String numI = jTextField11.getText();

            String Query = "SELECT * FROM pfe_schema.stock WHERE N°inventaire LIKE '%" + numI + "%' AND Affecté = 'Oui';";
            try {
                ResultSet rs = null;

                st = con.createStatement();
                rs = st.executeQuery(Query);

                DefaultTableModel model = (DefaultTableModel) jTable6.getModel();
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11)});
                }
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        } else if (jComboBox8.getSelectedItem() == "Caractéristiques") {
            String txtR = jTextField11.getText();
            String Query = "SELECT * FROM pfe_schema.stock WHERE Caractéristiques LIKE '%" + txtR + "%' AND Affecté = 'Oui';";
            try {
                ResultSet rs = null;

                st = con.createStatement();
                rs = st.executeQuery(Query);

                DefaultTableModel model = (DefaultTableModel) jTable6.getModel();
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11)});
                }
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        }
    }//GEN-LAST:event_jTextField11ActionPerformed

    private void jTable6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable6MouseClicked
        int row = jTable6.getSelectedRow();

        nomMat2 = (String) jTable6.getValueAt(row, 1);
        num2 = (String) jTable6.getValueAt(row, 2);
        carac2 = (String) jTable6.getValueAt(row, 3);
        Aff = (String) jTable6.getValueAt(row, 8);
        Loca = (String) jTable6.getValueAt(row, 10);
    }//GEN-LAST:event_jTable6MouseClicked

    private void jButton31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton31ActionPerformed

        int selectedRow = jTable6.getSelectedRow();

        if (selectedRow != -1) {
            if ("Oui".equals(Aff)) {

                DefaultTableModel model2 = (DefaultTableModel) jTable6.getModel();
                jTable6.clearSelection();

                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                LocalDateTime now = LocalDateTime.now();

                String nvLocation = jTextField16.getText();
                String cause = jTextField15.getText();

                String query = "INSERT INTO pfe_schema.maintenance (NomMatériel, `N°inventaire`, Caractéristiques, Affecté, Localisation, `NV Localisation`, Cause , Date) "
                + "VALUES ("
                + " '" + nomMat2 + "',"
                + " '" + num2 + "',"
                + " '" + carac2 + "',"
                + " '" + Aff + "',"
                + " '" + Loca + "',"
                + " '" + nvLocation + "',"
                + " '" + cause + "',"
                + " '" + dtf.format(now) + "')";

                try {
                    // Disable auto-commit mode
                    con.setAutoCommit(false);

                    st = con.createStatement();
                    st.executeUpdate(query);
                    // Commit the transaction
                    con.commit();

                    // Re-enable auto-commit mode
                    con.setAutoCommit(true);

                    loadDB(71);
                    loadDB(70);
                } catch (SQLException ex) {
                    Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                    // Rollback the transaction on error
                    try {
                        con.rollback();
                    } catch (SQLException ex2) {
                        Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                    }
                } catch (Exception e) {
                    System.out.print("exp :" + e);
                }

                System.out.print("selected");
            } else if ("Oui".equals(Aff)) {
                JOptionPane.showMessageDialog(null, "Ce Materiel Manque l'attribue 'Affecter' ", "Message", JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Vous devez sélectionner un Materiel", "Message", JOptionPane.INFORMATION_MESSAGE);
            System.out.print("not selected");
        }
    }//GEN-LAST:event_jButton31ActionPerformed

    private void jButton26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton26ActionPerformed
        jLayeredPane1.removeAll();
        jLayeredPane1.add(jPanel8);
        jLayeredPane1.repaint();
        jLayeredPane1.revalidate();
        System.out.print("jPanel8");
        try {
            loadDB(71);
            loadDB(70);
        } catch (SQLException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton26ActionPerformed

    private void jTable7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable7MouseClicked
        jButton50.setEnabled(true);

        int row = jTable7.getSelectedRow();

        ref = (String) jTable7.getValueAt(row, 1);
        REF = Integer.parseInt(ref);
        cat = (String) jTable7.getValueAt(row, 9);
    }//GEN-LAST:event_jTable7MouseClicked

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        if (tour2 == 0) {
            jButton15.setText("Back");
            jButton15.setBackground(new Color(255, 46, 99));

            jScrollPane7.setVisible(true);
            jButton50.setVisible(true);
            jButton50.setEnabled(false);
            jLabel5.setVisible(true);

            jTable7.getColumnModel().getColumn(10).setPreferredWidth(150);

            jScrollPane2.setVisible(false);
            jScrollPane3.setVisible(false);
            jLabel4.setVisible(false);
            jLabel22.setVisible(false);
            jLabel6.setVisible(false);
            jComboBox1.setVisible(false);
            jComboBox2.setVisible(false);
            jButton19.setVisible(false);
            jPanel28.setVisible(false);
            jButton20.setVisible(false);

            tour2 = 1;
        } else if (tour2 == 1) {
            jButton15.setText("Assignment history");
            jButton15.setBackground(new Color(102, 153, 255));

            jScrollPane7.setVisible(false);
            jButton50.setVisible(false);
            jButton50.setEnabled(false);
            jLabel5.setVisible(false);

            jScrollPane2.setVisible(true);
            jScrollPane3.setVisible(true);
            jLabel4.setVisible(true);
            jLabel22.setVisible(true);
            jLabel6.setVisible(true);
            jComboBox1.setVisible(true);
            jComboBox2.setVisible(true);
            jButton19.setVisible(true);
            jPanel28.setVisible(true);
            jButton20.setVisible(true);

            tour2 = 0;
        }
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jComboBox4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox4ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
        try {
            loadDB(2);
        } catch (SQLException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton18ActionPerformed

    private void jTextField8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField8ActionPerformed

        if (jComboBox4.getSelectedItem() == "Nom Matériel") {
            String txtR = jTextField8.getText();
            String Query = "SELECT * FROM pfe_schema.stock WHERE NomMatériel LIKE '%" + txtR + "%';";
            try {
                ResultSet rs = null;

                st = con.createStatement();
                rs = st.executeQuery(Query);

                DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11)});
                }
                calculateTotal(1);
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        } else if (jComboBox4.getSelectedItem() == "N°inventaire") {
            String numI = jTextField8.getText();

            String Query = "SELECT * FROM pfe_schema.stock WHERE N°inventaire LIKE '%" + numI + "%';";
            try {
                ResultSet rs = null;

                st = con.createStatement();
                rs = st.executeQuery(Query);

                DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11)});
                }
                calculateTotal(1);
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        } else if (jComboBox4.getSelectedItem() == "Caractéristiques") {
            String txtR = jTextField8.getText();
            String Query = "SELECT * FROM pfe_schema.stock WHERE Caractéristiques LIKE '%" + txtR + "%';";
            try {
                ResultSet rs = null;

                st = con.createStatement();
                rs = st.executeQuery(Query);

                DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11)});
                }
                calculateTotal(1);
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }
        }
    }//GEN-LAST:event_jTextField8ActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        int row = jTable2.getSelectedRow();

        idM = (String) jTable2.getValueAt(row, 0);
        IDM = Integer.parseInt(idM);
        nomMat2 = (String) jTable2.getValueAt(row, 1);
        num2 = (String) jTable2.getValueAt(row, 2);
        carac2 = (String) jTable2.getValueAt(row, 3);
        etats2 = (String) jTable2.getValueAt(row, 4);
        date2 = (String) jTable2.getValueAt(row, 5);
        Cons2 = (String) jTable2.getValueAt(row, 6);
        Desc2 = (String) jTable2.getValueAt(row, 7);
        Aff = (String) jTable2.getValueAt(row, 8);
    }//GEN-LAST:event_jTable2MouseClicked

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed

        DefaultTableModel model = (DefaultTableModel) jTable3.getModel();
        model.setRowCount(0);

        jTable2.clearSelection();
        nomMat2 = "";
        num2 = "";
        carac2 = "";
        etats2 = "";
        date2 = "";
        Cons2 = "";
        Desc2 = "";
    }//GEN-LAST:event_jButton20ActionPerformed

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed

        int selectedRow = jTable2.getSelectedRow();
        if (selectedRow != -1) {
            if ("Non".equals(Aff)) {

                DefaultTableModel model = (DefaultTableModel) jTable3.getModel();
                model.addRow(new Object[]{nomMat2, num2, carac2, etats2, jComboBox1.getSelectedItem(), jComboBox2.getSelectedItem()});

                DefaultTableModel model2 = (DefaultTableModel) jTable2.getModel();
                jTable2.clearSelection();

                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                LocalDateTime now = LocalDateTime.now();

                String selectedLocation = (String) jComboBox2.getSelectedItem();

                if (selectedLocation.equals("ST") || selectedLocation.equals("DROIT") || selectedLocation.equals("LLSH") || selectedLocation.equals("SEGSH")) {

                    String query = "INSERT INTO pfe_schema.stockfaculteattente (Ref, NomMatériel, N°inventaire, Caractéristiques, Etats, DateMiseEnService, Consommable, Description, Affecté, Localisation) "
                    + "VALUES ('" + IDM + "', "
                    + " '" + nomMat2 + "',"
                    + " '" + num2 + "',"
                    + " '" + carac2 + "',"
                    + " '" + etats2 + "',"
                    + " '" + date2 + "',"
                    + " '" + Cons2 + "',"
                    + " '" + Desc2 + "',"
                    + " 'Non',"
                    + " '" + jComboBox2.getSelectedItem() + "')";

                    try {
                        // Disable auto-commit mode
                        con.setAutoCommit(false);

                        st = con.createStatement();
                        st.executeUpdate(query);

                        // Commit the transaction
                        con.commit();

                        // Re-enable auto-commit mode
                        con.setAutoCommit(true);

                    } catch (SQLException ex) {
                        Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                        // Rollback the transaction on error
                        try {
                            con.rollback();
                        } catch (SQLException ex2) {
                            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                        }
                    } catch (Exception e) {
                        System.out.print("exp :" + e);
                    }
                }

                if (jComboBox1.getSelectedItem() == "Computer Science") {

                    String QueryUpdate = "UPDATE pfe_schema.stock "
                    + " SET Affecté = 'Oui', Localisation = '" + jComboBox2.getSelectedItem() + "' "
                    + " WHERE id = " + IDM + ";";

                    String Query = "INSERT INTO pfe_schema.materielinfo (Ref, NomMatériel, N°inventaire, Caractéristiques, Etats, DateMiseEnService, Consommable, Description, Localisation) "
                    + "VALUES ('" + IDM + "', "
                    + "'" + nomMat2 + "', "
                    + "'" + num2 + "', "
                    + "'" + carac2 + "', "
                    + "'" + etats2 + "', "
                    + "'" + date2 + "', "
                    + "'" + Cons2 + "', "
                    + "'" + Desc2 + "', "
                    + "'" + jComboBox2.getSelectedItem() + "') ";

                    String QueryH = "INSERT INTO pfe_schema.historique (Ref, NomMatériel, N°inventaire, Caractéristiques, Etats, DateMiseEnService, Consommable, Description, Catégorie, Localisation, Date) "
                    + "VALUES ('"
                    + "" + IDM + "', "
                    + "'" + nomMat2 + "', "
                    + " '" + num2 + "' , "
                    + " '" + carac2 + "' , "
                    + " '" + etats2 + "' , "
                    + " '" + date2 + "' , "
                    + " '" + Cons2 + "' , "
                    + " '" + Desc2 + "' , "
                    + " '" + jComboBox1.getSelectedItem() + "' , "
                    + " '" + jComboBox2.getSelectedItem() + "' , "
                    + " '" + dtf.format(now) + "' "
                    + ");";

                    try {
                        // Disable auto-commit mode
                        con.setAutoCommit(false);

                        // Execute the SQL statement within the transaction
                        PreparedStatement pstmt = con.prepareStatement(QueryUpdate);
                        pstmt.executeUpdate();

                        st = con.createStatement();
                        st.executeUpdate(Query);

                        st = con.createStatement();
                        st.executeUpdate(QueryH);

                        // Commit the transaction
                        con.commit();

                        // Re-enable auto-commit mode
                        con.setAutoCommit(true);

                        loadDB(2);
                        loadDB(3);
                        loadDB(9);
                    } catch (SQLException ex) {
                        Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                        // Rollback the transaction on error
                        try {
                            con.rollback();
                        } catch (SQLException ex2) {
                            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                        }
                    } catch (Exception e) {
                        System.out.print("exp :" + e);
                    }
                } else if (jComboBox1.getSelectedItem() == "Scientific") {

                    String QueryUpdate = "UPDATE pfe_schema.stock "
                    + " SET Affecté = 'Oui', Localisation = '" + jComboBox2.getSelectedItem() + "' "
                    + " WHERE id = " + IDM + ";";

                    String Query = "INSERT INTO pfe_schema.materielscientifique (Ref, NomMatériel, N°inventaire, Caractéristiques, Etats, DateMiseEnService, Consommable, Description, Localisation) "
                    + "VALUES ('" + IDM + "', "
                    + "'" + nomMat2 + "', "
                    + "'" + num2 + "', "
                    + "'" + carac2 + "', "
                    + "'" + etats2 + "', "
                    + "'" + date2 + "', "
                    + "'" + Cons2 + "', "
                    + "'" + Desc2 + "', "
                    + "'" + jComboBox2.getSelectedItem() + "') ";

                    String QueryH = "INSERT INTO pfe_schema.historique (Ref, NomMatériel, N°inventaire, Caractéristiques, Etats, DateMiseEnService, Consommable, Description, Catégorie, Localisation, Date) "
                    + "VALUES ('"
                    + "" + IDM + "', "
                    + "'" + nomMat2 + "', "
                    + " '" + num2 + "' , "
                    + " '" + carac2 + "' , "
                    + " '" + etats2 + "' , "
                    + " '" + date2 + "' , "
                    + " '" + Cons2 + "' , "
                    + " '" + Desc2 + "' , "
                    + " '" + jComboBox1.getSelectedItem() + "' , "
                    + " '" + jComboBox2.getSelectedItem() + "' , "
                    + " '" + dtf.format(now) + "' "
                    + ");";

                    try {
                        // Disable auto-commit mode
                        con.setAutoCommit(false);

                        // Execute the SQL statement within the transaction
                        PreparedStatement pstmt = con.prepareStatement(QueryUpdate);
                        pstmt.executeUpdate();

                        st = con.createStatement();
                        st.executeUpdate(Query);

                        st = con.createStatement();
                        st.executeUpdate(QueryH);

                        // Commit the transaction
                        con.commit();

                        // Re-enable auto-commit mode
                        con.setAutoCommit(true);

                        loadDB(2);
                        loadDB(4);
                        loadDB(9);
                    } catch (SQLException ex) {
                        Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                        // Rollback the transaction on error
                        try {
                            con.rollback();
                        } catch (SQLException ex2) {
                            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                        }
                    } catch (Exception e) {
                        System.out.print("exp :" + e);
                    }
                } else if (jComboBox1.getSelectedItem() == "Scientific Research") {

                    String QueryUpdate = "UPDATE pfe_schema.stock "
                    + " SET Affecté = 'Oui', Localisation = '" + jComboBox2.getSelectedItem() + "' "
                    + " WHERE id = " + IDM + ";";

                    String Query = "INSERT INTO pfe_schema.materielrecherchescientifique (Ref, NomMatériel, N°inventaire, Caractéristiques, Etats, DateMiseEnService, Consommable, Description, Localisation) "
                    + "VALUES ('" + IDM + "', "
                    + "'" + nomMat2 + "', "
                    + "'" + num2 + "', "
                    + "'" + carac2 + "', "
                    + "'" + etats2 + "', "
                    + "'" + date2 + "', "
                    + "'" + Cons2 + "', "
                    + "'" + Desc2 + "', "
                    + "'" + jComboBox2.getSelectedItem() + "') ";

                    String QueryH = "INSERT INTO pfe_schema.historique (Ref, NomMatériel, N°inventaire, Caractéristiques, Etats, DateMiseEnService, Consommable, Description, Catégorie, Localisation, Date) "
                    + "VALUES ('"
                    + "" + IDM + "', "
                    + "'" + nomMat2 + "', "
                    + " '" + num2 + "' , "
                    + " '" + carac2 + "' , "
                    + " '" + etats2 + "' , "
                    + " '" + date2 + "' , "
                    + " '" + Cons2 + "' , "
                    + " '" + Desc2 + "' , "
                    + " '" + jComboBox1.getSelectedItem() + "' , "
                    + " '" + jComboBox2.getSelectedItem() + "' , "
                    + " '" + dtf.format(now) + "' "
                    + ");";

                    try {
                        // Disable auto-commit mode
                        con.setAutoCommit(false);

                        // Execute the SQL statement within the transaction
                        PreparedStatement pstmt = con.prepareStatement(QueryUpdate);
                        pstmt.executeUpdate();

                        st = con.createStatement();
                        st.executeUpdate(Query);

                        st = con.createStatement();
                        st.executeUpdate(QueryH);

                        // Commit the transaction
                        con.commit();

                        // Re-enable auto-commit mode
                        con.setAutoCommit(true);

                        loadDB(2);
                        loadDB(4);
                        loadDB(9);
                    } catch (SQLException ex) {
                        Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                        // Rollback the transaction on error
                        try {
                            con.rollback();
                        } catch (SQLException ex2) {
                            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                        }
                    } catch (Exception e) {
                        System.out.print("exp :" + e);
                    }
                } else if (jComboBox1.getSelectedItem() == "Pédagogique") {

                    String QueryUpdate = "UPDATE pfe_schema.stock "
                    + " SET Affecté = 'Oui', Localisation = '" + jComboBox2.getSelectedItem() + "' "
                    + " WHERE id = " + IDM + ";";

                    String Query = "INSERT INTO pfe_schema.materielpedagogique (Ref, NomMatériel, N°inventaire, Caractéristiques, Etats, DateMiseEnService, Consommable, Description, Localisation) "
                    + "VALUES ('" + IDM + "', "
                    + "'" + nomMat2 + "', "
                    + "'" + num2 + "', "
                    + "'" + carac2 + "', "
                    + "'" + etats2 + "', "
                    + "'" + date2 + "', "
                    + "'" + Cons2 + "', "
                    + "'" + Desc2 + "', "
                    + "'" + jComboBox2.getSelectedItem() + "') ";

                    String QueryH = "INSERT INTO pfe_schema.historique (Ref, NomMatériel, N°inventaire, Caractéristiques, Etats, DateMiseEnService, Consommable, Description, Catégorie, Localisation, Date) "
                    + "VALUES ('"
                    + "" + IDM + "', "
                    + "'" + nomMat2 + "', "
                    + " '" + num2 + "' , "
                    + " '" + carac2 + "' , "
                    + " '" + etats2 + "' , "
                    + " '" + date2 + "' , "
                    + " '" + Cons2 + "' , "
                    + " '" + Desc2 + "' , "
                    + " '" + jComboBox1.getSelectedItem() + "' , "
                    + " '" + jComboBox2.getSelectedItem() + "' , "
                    + " '" + dtf.format(now) + "' "
                    + ");";

                    try {
                        // Disable auto-commit mode
                        con.setAutoCommit(false);

                        // Execute the SQL statement within the transaction
                        PreparedStatement pstmt = con.prepareStatement(QueryUpdate);
                        pstmt.executeUpdate();

                        st = con.createStatement();
                        st.executeUpdate(Query);

                        st = con.createStatement();
                        st.executeUpdate(QueryH);

                        // Commit the transaction
                        con.commit();

                        // Re-enable auto-commit mode
                        con.setAutoCommit(true);

                        loadDB(2);
                        loadDB(5);
                        loadDB(9);
                    } catch (SQLException ex) {
                        Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                        // Rollback the transaction on error
                        try {
                            con.rollback();
                        } catch (SQLException ex2) {
                            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                        }
                    } catch (Exception e) {
                        System.out.print("exp :" + e);
                    }
                } else if (jComboBox1.getSelectedItem() == "Movable") {

                    String QueryUpdate = "UPDATE pfe_schema.stock "
                    + " SET Affecté = 'Oui', Localisation = '" + jComboBox2.getSelectedItem() + "' "
                    + " WHERE id = " + IDM + ";";

                    String Query = "INSERT INTO pfe_schema.materielmobilier (Ref, NomMatériel, N°inventaire, Caractéristiques, Etats, DateMiseEnService, Consommable, Description, Localisation) "
                    + "VALUES ('" + IDM + "', "
                    + "'" + nomMat2 + "', "
                    + "'" + num2 + "', "
                    + "'" + carac2 + "', "
                    + "'" + etats2 + "', "
                    + "'" + date2 + "', "
                    + "'" + Cons2 + "', "
                    + "'" + Desc2 + "', "
                    + "'" + jComboBox2.getSelectedItem() + "') ";

                    String QueryH = "INSERT INTO pfe_schema.historique (Ref, NomMatériel, N°inventaire, Caractéristiques, Etats, DateMiseEnService, Consommable, Description, Catégorie, Localisation, Date) "
                    + "VALUES ('"
                    + "" + IDM + "', "
                    + "'" + nomMat2 + "', "
                    + " '" + num2 + "' , "
                    + " '" + carac2 + "' , "
                    + " '" + etats2 + "' , "
                    + " '" + date2 + "' , "
                    + " '" + Cons2 + "' , "
                    + " '" + Desc2 + "' , "
                    + " '" + jComboBox1.getSelectedItem() + "' , "
                    + " '" + jComboBox2.getSelectedItem() + "' , "
                    + " '" + dtf.format(now) + "' "
                    + ");";

                    try {
                        // Disable auto-commit mode
                        con.setAutoCommit(false);

                        // Execute the SQL statement within the transaction
                        PreparedStatement pstmt = con.prepareStatement(QueryUpdate);
                        pstmt.executeUpdate();

                        st = con.createStatement();
                        st.executeUpdate(Query);

                        st = con.createStatement();
                        st.executeUpdate(QueryH);

                        // Commit the transaction
                        con.commit();

                        // Re-enable auto-commit mode
                        con.setAutoCommit(true);

                        loadDB(2);
                        loadDB(13);
                        loadDB(9);
                    } catch (SQLException ex) {
                        Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                        // Rollback the transaction on error
                        try {
                            con.rollback();
                        } catch (SQLException ex2) {
                            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                        }
                    } catch (Exception e) {
                        System.out.print("exp :" + e);
                    }
                }

                System.out.print("selected");
            } else if ("Oui".equals(Aff)) {
                JOptionPane.showMessageDialog(null, "Ce Materiel est déja Affecter", "Message", JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Vous devez sélectionner un Materiel", "Message", JOptionPane.INFORMATION_MESSAGE);
            System.out.print("not selected");
        }
    }//GEN-LAST:event_jButton19ActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        String selectedItem = (String) jComboBox2.getSelectedItem();
        if (selectedItem.equals("Facultés")) {
            jComboBox2.removeAllItems();
            try {
                loadDB(111);
                String[] allItems = Arrays.copyOf(items.toArray(new String[0]), items.size()/* + additionalItems.length*/);
                //System.arraycopy(additionalItems, 0, allItems, items.size(), additionalItems.length);

                DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(allItems);
                jComboBox2.getModel();
                jComboBox2.setModel(model);

            } catch (SQLException ex) {
                Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
            }
            jComboBox2.addItem("Retour");
        } else if (selectedItem.equals("SG")) {
            jComboBox2.removeAllItems();
            jComboBox2.addItem("CRI");
            jComboBox2.addItem("SDPF");
            jComboBox2.addItem("SDFC");
            jComboBox2.addItem("SDNG");
            jComboBox2.addItem("SDASC");
            jComboBox2.addItem("Retour");
        } else if (selectedItem.equals("Retour")) {
            try {
                loadDB(11);
            } catch (SQLException ex) {
                Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
            }
            String[] allItems = Arrays.copyOf(items.toArray(new String[0]), items.size() + additionalItems.length);
            System.arraycopy(additionalItems, 0, allItems, items.size(), additionalItems.length);

            DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(allItems);
            jComboBox2.getModel();
            jComboBox2.setModel(model);
        }
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jButton50ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton50ActionPerformed

        int dialogResult = JOptionPane.showConfirmDialog(null, "Êtes-vous sûr de vouloir retourner ce enregistrement ?", "Confirmation", JOptionPane.YES_NO_OPTION);
        if (dialogResult == JOptionPane.YES_OPTION) {
            String Query = "DELETE FROM pfe_schema.historique WHERE Ref = '" + REF + "'";

            String QueryUpdate = "UPDATE pfe_schema.stock "
            + " SET Affecté = 'Non', Localisation = '' "
            + " WHERE id = " + REF + ";";

            try {
                ResultSet rs = null;

                // Disable auto-commit mode
                con.setAutoCommit(false);

                // Execute the SQL statement within the transaction
                PreparedStatement pstmt = con.prepareStatement(QueryUpdate);
                pstmt.executeUpdate();

                st = con.createStatement();
                st.executeUpdate(Query);

                // Commit the transaction
                con.commit();

                // Re-enable auto-commit mode
                con.setAutoCommit(true);
                loadDB(1);
                loadDB(9);
                loadDB(2);
            } catch (SQLException ex) {
                Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                // Rollback the transaction on error
                try {
                    con.rollback();
                } catch (SQLException ex2) {
                    Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                }
            } catch (Exception e) {
                System.out.print("exp :" + e);
            }

            if (null != cat) {
                switch (cat) {
                    case "Informatique":
                    String Queryi = " DELETE FROM pfe_schema.materielinfo "
                    + "WHERE Ref = " + REF + " ;";
                    try {
                        // Disable auto-commit mode
                        con.setAutoCommit(false);

                        st = con.createStatement();
                        st.executeUpdate(Queryi);

                        // Commit the transaction
                        con.commit();

                        // Re-enable auto-commit mode
                        con.setAutoCommit(true);

                        loadDB(3);

                    } catch (SQLException ex) {
                        Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                        // Rollback the transaction on error
                        try {
                            con.rollback();
                        } catch (SQLException ex2) {
                            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                        }
                    } catch (Exception e) {
                        System.out.print("exp :" + e);
                    }
                    break;
                    case "Scientifique":
                    String Querys = " DELETE FROM pfe_schema.materielscientifique "
                    + "WHERE Ref = " + REF + " ;";
                    try {
                        // Disable auto-commit mode
                        con.setAutoCommit(false);

                        st = con.createStatement();
                        st.executeUpdate(Querys);

                        // Commit the transaction
                        con.commit();

                        // Re-enable auto-commit mode
                        con.setAutoCommit(true);

                        loadDB(4);

                    } catch (SQLException ex) {
                        Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                        // Rollback the transaction on error
                        try {
                            con.rollback();
                        } catch (SQLException ex2) {
                            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                        }
                    } catch (Exception e) {
                        System.out.print("exp :" + e);
                    }
                    break;
                    case "Recherche Scientifique":
                    String Queryrs = " DELETE FROM pfe_schema.materielrecherchescientifique "
                    + "WHERE Ref = " + REF + " ;";
                    try {
                        // Disable auto-commit mode
                        con.setAutoCommit(false);

                        st = con.createStatement();
                        st.executeUpdate(Queryrs);

                        // Commit the transaction
                        con.commit();

                        // Re-enable auto-commit mode
                        con.setAutoCommit(true);

                        loadDB(14);

                    } catch (SQLException ex) {
                        Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                        // Rollback the transaction on error
                        try {
                            con.rollback();
                        } catch (SQLException ex2) {
                            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                        }
                    } catch (Exception e) {
                        System.out.print("exp :" + e);
                    }
                    break;
                    case "Pédagogique":
                    String Queryp = " DELETE FROM pfe_schema.materielpedagogique "
                    + "WHERE Ref = " + REF + " ;";
                    try {
                        // Disable auto-commit mode
                        con.setAutoCommit(false);

                        st = con.createStatement();
                        st.executeUpdate(Queryp);

                        // Commit the transaction
                        con.commit();

                        // Re-enable auto-commit mode
                        con.setAutoCommit(true);

                        loadDB(5);

                    } catch (SQLException ex) {
                        Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                        // Rollback the transaction on error
                        try {
                            con.rollback();
                        } catch (SQLException ex2) {
                            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                        }
                    } catch (Exception e) {
                        System.out.print("exp :" + e);
                    }
                    break;
                    case "Mobilier":
                    String Querym = " DELETE FROM pfe_schema.materielmobilier "
                    + "WHERE Ref = " + REF + " ;";
                    try {
                        // Disable auto-commit mode
                        con.setAutoCommit(false);

                        st = con.createStatement();
                        st.executeUpdate(Querym);

                        // Commit the transaction
                        con.commit();

                        // Re-enable auto-commit mode
                        con.setAutoCommit(true);

                        loadDB(13);

                    } catch (SQLException ex) {
                        Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);

                        // Rollback the transaction on error
                        try {
                            con.rollback();
                        } catch (SQLException ex2) {
                            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex2);
                        }
                    } catch (Exception e) {
                        System.out.print("exp :" + e);
                    }
                    break;
                    default:
                    break;
                }
            }

        }
    }//GEN-LAST:event_jButton50ActionPerformed

    private void loadFirstScreen() {
        jLayeredPane1.removeAll();
        jLayeredPane1.add(jPanel4);
        jLayeredPane1.repaint();
        jLayeredPane1.revalidate();

    }

    public void loadMessagerie() {
        // Create a list to hold the data
        ArrayList<String[]> dataList = new ArrayList<String[]>();

        DefaultListModel<String> listModel = new DefaultListModel<>();

        try {
            ResultSet rs = st.executeQuery("SELECT utilisateur, message, date FROM pfe_schema.messagerie_viserecteur;");

            // Loop through the result set and add each row to the list
            while (rs.next()) {
                String utilisateur = rs.getString("utilisateur");
                String message = rs.getString("message");
                String date = rs.getString("date");
                String[] row = {utilisateur, message, date};
                dataList.add(row);
            }

            // Convert the list to a 2D array
            String[][] data = new String[dataList.size()][3];
            for (int i = 0; i < dataList.size(); i++) {
                data[i] = dataList.get(i);
            }

            for (int i = 0; i < data.length; i++) {
                String[] itemData = data[i];
                String itemText = "<html><body>"
                        + "<b>User:</b> " + itemData[0] + "<br>"
                        + "<b>Message:</b> " + itemData[1] + "<br>"
                        + "<b>Date:</b> " + itemData[2] + "<br>"
                        + "<b>----------------------------------------------------------------------------------------------------------------</body></html>";

                //String separator = "<html><hr style='border-top: 1px solid #8c8b8b;'></html>";
                listModel.addElement(itemText);
            }

            int size = listModel.getSize();
            if (size > 1) {
                int i = 0;
                int j = size - 1;
                while (i < j) {
                    String temp = listModel.getElementAt(i);
                    listModel.setElementAt(listModel.getElementAt(j), i);
                    listModel.setElementAt(temp, j);
                    i++;
                    j--;
                }
                jList1.setSelectedIndex(0);
            }

            jList1.setModel(listModel);

        } catch (SQLException ex) {
            Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
        }

        // Set a custom renderer for the JList to display line breaks and separators
        jList1.setCellRenderer(new DefaultListCellRenderer() {
            public void setValue(Object value) {
                if (value instanceof String) {
                    setText((String) value);
                    setFont(getFont().deriveFont(14f));
                } else {
                    setText((value == null) ? "" : value.toString());
                    setFont(getFont().deriveFont(16f));
                }
                setEnabled(true);
            }
        });

        int listSize = jList1.getModel().getSize();
        jLabel27.setText("" + listSize);
    }

    public void calculateTotal(int i) {
        if (i == 1) {
            //total GDS
            int total = jTable1.getRowCount();
            jLabel13.setText(" " + total);
        } else if (i == 2) {
            //total MAT info
            int total = jTable4.getRowCount();
            jLabel28.setText(" " + total);
        } else if (i == 3) {
            //total MAT science
            int total = jTable5.getRowCount();
            jLabel32.setText(" " + total);
        } else if (i == 5) {
            //total MAT science
            int total = jTable8.getRowCount();
            jLabel41.setText(" " + total);
        } else if (i == 6) {
            //total MAT science
            int total = jTable10.getRowCount();
            jLabel38.setText(" " + total);
        } else if (i == 7) {
            //total MAT science
            int total = jTable11.getRowCount();
            jLabel33.setText(" " + total);
        }
    }

    public void loadDB(int i) throws SQLException, IOException {
        ResultSet rs;

        st = con.createStatement();

        if (i == 1) {
            rs = st.executeQuery("SELECT * FROM stock");
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            model.setRowCount(0);
            while (rs.next()) {
                model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11)});
            }
        } else if (i == 2) {
            rs = st.executeQuery("SELECT * FROM stock");
            DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
            model.setRowCount(0);
            while (rs.next()) {
                model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11)});
            }
        } else if (i == 71) {
            rs = st.executeQuery("SELECT * FROM stock WHERE Affecté = 'Oui';");
            DefaultTableModel model = (DefaultTableModel) jTable6.getModel();
            model.setRowCount(0);
            while (rs.next()) {
                model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11)});
            }
        } else if (i == 70) {
            rs = st.executeQuery("SELECT * FROM pfe_schema.maintenance");
            DefaultTableModel model = (DefaultTableModel) jTable13.getModel();
            model.setRowCount(0);
            while (rs.next()) {
                model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9)});
            }
        } else if (i == 3) {
            rs = st.executeQuery("SELECT * FROM pfe_schema.materielinfo;");
            DefaultTableModel model = (DefaultTableModel) jTable4.getModel();
            model.setRowCount(0);
            while (rs.next()) {
                model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10)});
            }
        } else if (i == 4) {
            rs = st.executeQuery("SELECT * FROM pfe_schema.materielscientifique;");
            DefaultTableModel model = (DefaultTableModel) jTable5.getModel();
            model.setRowCount(0);
            while (rs.next()) {
                model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10)});
            }
        } else if (i == 9) {
            rs = st.executeQuery("SELECT * FROM pfe_schema.historique;");
            DefaultTableModel model = (DefaultTableModel) jTable7.getModel();
            model.setRowCount(0);
            while (rs.next()) {
                model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11), rs.getString(12)});
            }
        } else if (i == 10) {
            rs = st.executeQuery("SELECT * FROM pfe_schema.faculte;");
            DefaultTableModel model = (DefaultTableModel) jTable8.getModel();
            model.setRowCount(0);
            while (rs.next()) {
                model.addRow(new String[]{rs.getString(1), rs.getString(2)});
            }
        } else if (i == 11) {
            items.clear();
            /*rs = st.executeQuery("SELECT Nom_département FROM pfe_schema.departements WHERE doyen IS NULL;");
            while (rs.next()) {
                String item = rs.getString("Nom_département");
                items.add(item);
            }*/
        } else if (i == 111) {
            items.clear();
            rs = st.executeQuery("SELECT * FROM pfe_schema.faculte;");
            while (rs.next()) {
                String item = rs.getString("Nom_Faculté");
                items.add(item);
            }
        } else if (i == 12) {
            rs = st.executeQuery("SELECT * FROM pfe_schema.profil_viserecteur;");
            DefaultTableModel model = (DefaultTableModel) jTable9.getModel();
            model.setRowCount(0);
            while (rs.next()) {
                model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(4)});
                jPasswordField1.setText((String) rs.getString(3));
            }

            ResultSet rsImg;
            try {
                rsImg = st.executeQuery("SELECT img FROM pfe_schema.profil_viserecteur WHERE id = 1;");
                if (rsImg.next()) {
                    byte[] imageData = rsImg.getBytes("img");
                    BufferedImage image = ImageIO.read(new ByteArrayInputStream(imageData));
                    jLabel2.setIcon(new ImageIcon(image));

                    jTextField14.setText((String) jTable9.getValueAt(0, 1));

                }
            } catch (SQLException ex) {
                Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(UT1.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (i == 13) {
            rs = st.executeQuery("SELECT * FROM pfe_schema.materielmobilier;");
            DefaultTableModel model = (DefaultTableModel) jTable10.getModel();
            model.setRowCount(0);
            while (rs.next()) {
                model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10)});
            }
        } else if (i == 14) {
            rs = st.executeQuery("SELECT * FROM pfe_schema.materielrecherchescientifique;");
            DefaultTableModel model = (DefaultTableModel) jTable11.getModel();
            model.setRowCount(0);
            while (rs.next()) {
                model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10)});
            }
        } else if (i == 40) {
            // Get the number of rows in each table
            ResultSet rs1 = st.executeQuery("SELECT COUNT(*) FROM pfe_schema.materielinfo");
            rs1.next();
            int count1 = rs1.getInt(1);

            ResultSet rs2 = st.executeQuery("SELECT COUNT(*) FROM pfe_schema.materielmobilier");
            rs2.next();
            int count2 = rs2.getInt(1);

            ResultSet rs3 = st.executeQuery("SELECT COUNT(*) FROM pfe_schema.materielpedagogique");
            rs3.next();
            int count3 = rs3.getInt(1);

            ResultSet rs4 = st.executeQuery("SELECT COUNT(*) FROM pfe_schema.materielrecherchescientifique");
            rs4.next();
            int count4 = rs4.getInt(1);

            ResultSet rs5 = st.executeQuery("SELECT COUNT(*) FROM pfe_schema.materielscientifique");
            rs5.next();
            int count5 = rs5.getInt(1);

            // Store the counts in a variable
            int totalCount = count1 + count2 + count3 + count4 + count5;
            popupLabel.setText(" " + totalCount + " Matériaux ");
        }

    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ViseRecteur.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ViseRecteur.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ViseRecteur.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ViseRecteur.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ViseRecteur().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton28;
    private javax.swing.JButton jButton29;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton31;
    private javax.swing.JButton jButton32;
    private javax.swing.JButton jButton33;
    private javax.swing.JButton jButton34;
    private javax.swing.JButton jButton35;
    private javax.swing.JButton jButton36;
    private javax.swing.JButton jButton37;
    private javax.swing.JButton jButton38;
    private javax.swing.JButton jButton39;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton40;
    private javax.swing.JButton jButton41;
    private javax.swing.JButton jButton42;
    private javax.swing.JButton jButton43;
    private javax.swing.JButton jButton44;
    private javax.swing.JButton jButton45;
    private javax.swing.JButton jButton47;
    private javax.swing.JButton jButton48;
    private javax.swing.JButton jButton49;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton50;
    private javax.swing.JButton jButton51;
    private javax.swing.JButton jButton52;
    private javax.swing.JButton jButton53;
    private javax.swing.JButton jButton54;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox10;
    private javax.swing.JComboBox<String> jComboBox11;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JComboBox<String> jComboBox5;
    private javax.swing.JComboBox<String> jComboBox6;
    private javax.swing.JComboBox<String> jComboBox7;
    private javax.swing.JComboBox<String> jComboBox8;
    private javax.swing.JComboBox<String> jComboBox9;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private com.toedter.calendar.JDateChooser jDateChooser2;
    private javax.swing.JFrame jFrame1;
    private javax.swing.JFrame jFrame2;
    private javax.swing.JFrame jFrame3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JLayeredPane jLayeredPane2;
    private javax.swing.JList<String> jList1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JMenuItem jMenuItem7;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JRadioButton jRadioButton4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable10;
    private javax.swing.JTable jTable11;
    private javax.swing.JTable jTable13;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable4;
    private javax.swing.JTable jTable5;
    private javax.swing.JTable jTable6;
    private javax.swing.JTable jTable7;
    private javax.swing.JTable jTable8;
    public javax.swing.JTable jTable9;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JTextField jTextField17;
    private javax.swing.JTextField jTextField18;
    private javax.swing.JTextField jTextField19;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField20;
    private javax.swing.JTextField jTextField21;
    private javax.swing.JTextField jTextField22;
    private javax.swing.JTextField jTextField23;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables

    public class RoundedPanel extends JPanel {

        private int arcWidth;
        private int arcHeight;
        private Color borderColor;

        public RoundedPanel(int arcWidth, int arcHeight, Color borderColor) {
            this.arcWidth = arcWidth;
            this.arcHeight = arcHeight;
            this.borderColor = borderColor;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), arcWidth, arcHeight);
            g2.setColor(borderColor);
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arcWidth, arcHeight);
            g2.dispose();
        }
    }

    public class RoundedLayeredPanel extends JLayeredPane {

        private int arcWidth;
        private int arcHeight;
        private Color borderColor;

        public RoundedLayeredPanel(int arcWidth, int arcHeight, Color borderColor) {
            this.arcWidth = arcWidth;
            this.arcHeight = arcHeight;
            this.borderColor = borderColor;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), arcWidth, arcHeight);
            g2.setColor(borderColor);
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arcWidth, arcHeight);
            g2.dispose();
        }

        public JPanel addRoundedPanel(int layer, JPanel panel, int x, int y, int width, int height) {
            RoundedPanel roundedPanel = new RoundedPanel(arcWidth, arcHeight, borderColor);
            roundedPanel.setBounds(x, y, width, height);
            roundedPanel.add(panel);
            add(roundedPanel, new Integer(layer));
            return roundedPanel;
        }

        private class RoundedPanel extends JPanel {

            private int arcWidth;
            private int arcHeight;
            private Color borderColor;

            public RoundedPanel(int arcWidth, int arcHeight, Color borderColor) {
                this.arcWidth = arcWidth;
                this.arcHeight = arcHeight;
                this.borderColor = borderColor;
                setOpaque(false);
            }

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), arcWidth, arcHeight);
                g2.setColor(borderColor);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arcWidth, arcHeight);
                g2.dispose();
            }
        }
    }

    public class RoundedBorder extends AbstractBorder {

        private Color color;
        private int arcWidth;
        private int arcHeight;

        public RoundedBorder(Color color, int arcWidth, int arcHeight) {
            this.color = color;
            this.arcWidth = arcWidth;
            this.arcHeight = arcHeight;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // Create a rounded rectangle with the same shape as the panel
            RoundRectangle2D.Float roundRect = new RoundRectangle2D.Float(x, y, width - 1, height - 1, arcWidth, arcHeight);

            // Draw the border
            g2d.setColor(color);
            g2d.draw(roundRect);

            g2d.dispose();
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(arcHeight, arcWidth, arcHeight, arcWidth);
        }

        @Override
        public Insets getBorderInsets(Component c, Insets insets) {
            insets.left = arcWidth;
            insets.top = arcHeight;
            insets.right = arcWidth;
            insets.bottom = arcHeight;
            return insets;
        }
    }

    public class RoundedLabel extends JLabel {

        private int arcWidth;
        private int arcHeight;

        public RoundedLabel() {
            super();
            setOpaque(true);
            arcWidth = 20;
            arcHeight = 20;
        }

        public RoundedLabel(String text) {
            super(text);
            setOpaque(true);
            arcWidth = 20;
            arcHeight = 20;
        }

        public RoundedLabel(ImageIcon icon) {
            super(icon);
            setOpaque(true);
            arcWidth = 20;
            arcHeight = 20;
        }

        public RoundedLabel(String text, ImageIcon icon, int horizontalAlignment) {
            super(text, icon, horizontalAlignment);
            setOpaque(true);
            arcWidth = 20;
            arcHeight = 20;
        }

        public RoundedLabel(int arcWidth, int arcHeight) {
            super();
            setOpaque(true);
            this.arcWidth = arcWidth;
            this.arcHeight = arcHeight;
        }

        public RoundedLabel(String text, int arcWidth, int arcHeight) {
            super(text);
            setOpaque(true);
            this.arcWidth = arcWidth;
            this.arcHeight = arcHeight;
        }

        public RoundedLabel(ImageIcon icon, int arcWidth, int arcHeight) {
            super(icon);
            setOpaque(true);
            this.arcWidth = arcWidth;
            this.arcHeight = arcHeight;
        }

        public RoundedLabel(String text, ImageIcon icon, int horizontalAlignment, int arcWidth, int arcHeight) {
            super(text, icon, horizontalAlignment);
            setOpaque(true);
            this.arcWidth = arcWidth;
            this.arcHeight = arcHeight;
        }

        public int getArcWidth() {
            return arcWidth;
        }

        public void setArcWidth(int arcWidth) {
            this.arcWidth = arcWidth;
            repaint();
        }

        public int getArcHeight() {
            return arcHeight;
        }

        public void setArcHeight(int arcHeight) {
            this.arcHeight = arcHeight;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            RoundRectangle2D.Float roundRect = new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), arcWidth, arcHeight);
            g2.clip(roundRect);
            super.paintComponent(g);
        }

        @Override
        protected void paintBorder(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(Color.white);
            RoundRectangle2D.Float roundRect = new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, arcWidth, arcHeight);
            g2.draw(roundRect);
        }
    }

    public class RoundedButton extends JButton {

        private static final long serialVersionUID = 1L;
        private int arcWidth;
        private int arcHeight;
        private Color borderColor; // new instance variable for the border color

        public RoundedButton(int arcWidth, int arcHeight) {
            this.arcWidth = arcWidth;
            this.arcHeight = arcHeight;
            this.borderColor = Color.BLACK; // default border color is black
            setContentAreaFilled(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fill(getShape());
            super.paintComponent(g);
        }

        @Override
        protected void paintBorder(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(borderColor);
            g2.setStroke(new BasicStroke(1)); // set border thickness to 2 pixels
            g2.draw(getShape());
        }

        private Shape getShape() {
            return new RoundRectangle2D.Double(0, 0, getWidth() - 1, getHeight() - 1, arcWidth, arcHeight);
        }

        // new setter method for the border color
        public void setBorderColor(Color color) {
            this.borderColor = color;
        }

    }

    public class RoundedJTextField extends JTextField {

        private Shape shape;

        public RoundedJTextField(int size) {
            super(size);
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            g.setColor(getBackground());
            g.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 40, 40);
            super.paintComponent(g);
        }

        @Override
        protected void paintBorder(Graphics g) {
            g.setColor(new Color(204, 204, 204));
            g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 40, 40);
        }

        @Override
        public boolean contains(int x, int y) {
            if (shape == null || !shape.getBounds().equals(getBounds())) {
                shape = new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 40, 40);
            }
            return shape.contains(x, y);
        }
    }

    //JTextArea
    public class RoundedJTextArea extends JTextArea {

        private Shape shape;

        public RoundedJTextArea(int rows, int columns) {
            super(rows, columns);
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            g.setColor(getBackground());
            g.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 30, 30);
            super.paintComponent(g);
        }

        @Override
        protected void paintBorder(Graphics g) {
            g.setColor(new Color(102, 102, 102));
            g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 30, 30);
        }

        @Override
        public boolean contains(int x, int y) {
            if (shape == null || !shape.getBounds().equals(getBounds())) {
                shape = new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 30, 30);
            }
            return shape.contains(x, y);
        }
    }

    public class RoundedJPasswordField extends JPasswordField {

        private Shape shape;

        public RoundedJPasswordField(int size) {
            super(size);
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            g.setColor(getBackground());
            g.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 40, 40);
            super.paintComponent(g);
        }

        @Override
        protected void paintBorder(Graphics g) {
            g.setColor(new Color(204, 204, 204));
            g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 40, 40);
        }

        @Override
        public boolean contains(int x, int y) {
            if (shape == null || !shape.getBounds().equals(getBounds())) {
                shape = new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 40, 40);
            }
            return shape.contains(x, y);
        }
    }
}
